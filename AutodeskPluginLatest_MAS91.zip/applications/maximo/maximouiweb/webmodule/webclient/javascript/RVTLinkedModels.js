/*
 * Licensed Materials - Property of IBM
 * 5737-M66, 5900-AAA, 5900-AMG
 * (C) Copyright IBM Corp. 2026 All Rights Reserved.
 * US Government Users Restricted Rights - Use, duplication, or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * RVTLinkedModels.js
 *
 * Handles selection and fitToView for linked Revit models (zip files with multiple RVT source files).
 * This module solves the externalId mapping issue where linked objects have different dbIds
 * than their base model counterparts.
 *
 * Problem: In linked Revit models, objects exist in multiple models with different dbIds.
 * The sidecar GUID map contains base model dbIds, but fitToView requires the linked model dbIds.
 *
 * Solution: Build a fast lookup index mapping base dbIds to linked dbIds using the
 * externalId mapping from Forge Viewer API.
 *
 * Note: This module is specifically designed for linked Revit models only.
 */

if( typeof IBM == "undefined" )
{
	IBM = {};
}
if( typeof IBM.LMV == "undefined" )
{
	IBM.LMV = {};
}

IBM.LMV.RVTLinkedModels = (function() {
	
	// Private variables
	var _externalIdMapping = {};
	var _dbIdToLinkedDbId = {};
	var _linkedDbIdToBaseDbId = {}; // Reverse lookup
	var _modelKeyMappings = {}; // Track mappings per model
	var _hostElementIds = []; // Cache host elements
	var _linkedElementIds = []; // Cache linked elements
	var _mappingLoading = false;
	var _selectionMgr = null;
	var _aecData = null; // Store AEC model data
	
	/**
	 * Validate that we're working with a proper linked Revit model
	 */
	async function validateLinkedModel(forgeViewer) {
		try {
			_aecData = await Autodesk.Viewing.Document.getAecModelData(
				forgeViewer.viewer.model.getDocumentNode()
			);
			
			return _aecData && _aecData.linkedDocuments && _aecData.linkedDocuments.length > 0;
		} catch(e) {
			return false;
		}
	}
	
	/**
	 * Get all leaf node dbIds from a model (synchronous)
	 */
	function getLeafNodes(model) {
		try {
			var instanceTree = model.getInstanceTree();
			var rootId = instanceTree.getRootId();
			var leafIds = [];
			
			function getLeafNodesRec(id) {
				var childCount = 0;
				instanceTree.enumNodeChildren(id, function(childId) {
					getLeafNodesRec(childId);
					childCount++;
				});
				
				if( childCount === 0 ) {
					leafIds.push(id);
				}
			}
			
			getLeafNodesRec(rootId);
			return leafIds;
		} catch(ex) {
			return [];
		}
	}
	
	/**
	 * Get linked element dbIds for specific link instance IDs
	 * Uses optimized filtering pattern from AU 2021 sample
	 */
	function getRevitLinkedElementIds(rvtLinkExternalIds, mapping) {
		var entities = Object.entries(mapping);
		var linkedElementIds = rvtLinkExternalIds.map(function(instanceId) {
			return entities
				.filter(function(entity) { return entity[0].includes(instanceId + "/"); })
				.map(function(entity) { return entity[1]; });
		}).flat();
		
		return linkedElementIds;
	}
	
	/**
	 * Separate host elements from linked elements (synchronous)
	 */
	function separateHostAndLinkedElements(model, rvtLinkExternalIds, mapping) {
		try {
			var linkedIds = getRevitLinkedElementIds(rvtLinkExternalIds, mapping);
			var leafIds = getLeafNodes(model);
			var hostIds = leafIds.filter(function(dbId) {
				return linkedIds.indexOf(dbId) === -1;
			});
			
			_hostElementIds = hostIds;
			_linkedElementIds = linkedIds;
		} catch(e) {
			// Silent fail - not critical for core functionality
		}
	}
	
	/**
	 * Called from Forge.js onGeometryLoad when _docType == "zip"
	 * Loads externalId mappings from all models and builds the lookup index
	 */
	function onGeometryLoad(selectionMgr, forgeViewer) {
		_selectionMgr = selectionMgr;
		
		// Start async validation but don't wait for it
		validateLinkedModel(forgeViewer);
		
		var allModels = forgeViewer.viewer.getAllModels ?
			forgeViewer.viewer.getAllModels() : [forgeViewer.viewer.model];
		
		var combinedMapping = {};
		var modelsToLoad = 0;
		var modelsLoaded = 0;
		
		for( var i = 0; i < allModels.length; i++ )
		{
			var model = allModels[i];
			
			if( model && model.getExternalIdMapping )
			{
				modelsToLoad++;
				_mappingLoading = true;
				(function(currentModel, modelIndex) {
					currentModel.getExternalIdMapping(function(mapping) {
						
						// Store mapping per model key for tracking
						var modelKey = currentModel.getModelKey ? currentModel.getModelKey() : modelIndex;
						_modelKeyMappings[modelKey] = mapping;
						
						// PASS 1: Build the complete combined mapping first
						for( var key in mapping )
						{
							combinedMapping[key] = mapping[key];
						}
						
						// PASS 2: Build the fast lookup index using optimized filtering
						// Filter linked keys first, then process
						var linkedKeys = Object.keys(mapping).filter(function(key) {
							return key.indexOf("/") !== -1;
						});
						
						linkedKeys.forEach(function(key) {
							var parts = key.split("/");
							if( parts.length === 2 )
							{
								var baseExtId = parts[1]; // The object GUID
								var linkedDbId = mapping[key]; // dbId in linked model
								var baseDbId = combinedMapping[baseExtId]; // dbId in base model
								
								if( baseDbId !== undefined )
								{
									_dbIdToLinkedDbId[baseDbId] = linkedDbId;
									_linkedDbIdToBaseDbId[linkedDbId] = baseDbId; // Reverse lookup
								}
							}
						});
						
						modelsLoaded++;
						if( modelsLoaded === modelsToLoad )
						{
							// All models loaded, store the combined mapping
							_externalIdMapping = combinedMapping;
							
							// Separate host and linked elements if we have AEC data
							if( _aecData && _aecData.linkedDocuments ) {
								var linkInstanceIds = _aecData.linkedDocuments.map(function(link) {
									return link.instanceId;
								});
								separateHostAndLinkedElements(
									forgeViewer.viewer.model,
									linkInstanceIds,
									combinedMapping
								);
							}
							
							// Mark mapping as complete BEFORE calling deferred search
							_mappingLoading = false;
							
							// Now that mapping is loaded, try deferred search again
							if( _selectionMgr )
							{
								_selectionMgr.doDeferedSearch();
							}
						}
					});
				})(model, i);
			}
		}
		
		// If no models have getExternalIdMapping, set empty mapping
		if( modelsToLoad === 0 )
		{
			_externalIdMapping = {};
			_mappingLoading = false;
		}
	}
	
	/**
	 * Called from Forge.js selectByGUID when _docType == "zip"
	 * Converts base model dbIds to linked model dbIds before selection
	 */
	function selectByGUID(selectionMgr, GUIDs, guid2dbIdArray, forgeViewer) {
		var searchResult = [];
		
		// Convert GUIDs to dbIds using the sidecar map
		for( var i = 0; i < GUIDs.length; i++ )
		{
			var baseDbId = guid2dbIdArray[ GUIDs[i] ];
			
			if( baseDbId != null )
			{
				// Check if this base dbId has a corresponding linked dbId
				if( _dbIdToLinkedDbId[baseDbId] !== undefined )
				{
					// Use the linked model dbId for proper fitToView
					searchResult.push(_dbIdToLinkedDbId[baseDbId]);
				}
				else
				{
					// No linked version found, use original dbId
					searchResult.push(baseDbId);
				}
			}
		}
		
		// Select the objects
		selectionMgr.select( searchResult );
		
		// Zoom to the selected objects
		if( searchResult.length > 0 )
		{
			try {
				forgeViewer.viewer.fitToView( searchResult, forgeViewer.viewer.model, true );
			} catch(e) {
				selectionMgr.zoomToContext( searchResult );
			}
		}
	}
	
	/**
	 * Check if mapping is currently loading
	 */
	function isMappingLoading() {
		return _mappingLoading;
	}
	
	/**
	 * Check if a dbId is from a linked model
	 */
	function isLinkedElement(dbId) {
		return _linkedElementIds.indexOf(dbId) !== -1;
	}
	
	/**
	 * Check if a dbId is from the host model
	 */
	function isHostElement(dbId) {
		return _hostElementIds.indexOf(dbId) !== -1;
	}
	
	/**
	 * Get the base model dbId for a linked model dbId
	 */
	function getBaseDbId(linkedDbId) {
		return _linkedDbIdToBaseDbId[linkedDbId];
	}
	
	/**
	 * Get the linked model dbId for a base model dbId
	 */
	function getLinkedDbId(baseDbId) {
		return _dbIdToLinkedDbId[baseDbId];
	}
	
	/**
	 * Get AEC model data (linked documents info)
	 */
	function getAecData() {
		return _aecData;
	}
	
	/**
	 * Get the current mapping (for debugging)
	 */
	function getMapping() {
		return {
			externalIdMapping: _externalIdMapping,
			dbIdToLinkedDbId: _dbIdToLinkedDbId,
			linkedDbIdToBaseDbId: _linkedDbIdToBaseDbId,
			modelKeyMappings: _modelKeyMappings,
			hostElementIds: _hostElementIds,
			linkedElementIds: _linkedElementIds,
			aecData: _aecData,
			stats: {
				totalMappings: Object.keys(_externalIdMapping).length,
				baseToLinkedMappings: Object.keys(_dbIdToLinkedDbId).length,
				linkedToBaseMappings: Object.keys(_linkedDbIdToBaseDbId).length,
				hostElements: _hostElementIds.length,
				linkedElements: _linkedElementIds.length,
				modelCount: Object.keys(_modelKeyMappings).length
			}
		};
	}
	
	/**
	 * Get detailed info about a specific dbId
	 */
	function getDbIdInfo(dbId) {
		var info = {
			dbId: dbId,
			isHost: isHostElement(dbId),
			isLinked: isLinkedElement(dbId),
			baseDbId: null,
			linkedDbId: null,
			externalId: null
		};
		
		// Find external ID
		for( var extId in _externalIdMapping ) {
			if( _externalIdMapping[extId] === dbId ) {
				info.externalId = extId;
				break;
			}
		}
		
		// Get related dbIds
		if( info.isLinked ) {
			info.baseDbId = getBaseDbId(dbId);
		} else {
			info.linkedDbId = getLinkedDbId(dbId);
		}
		
		return info;
	}
	
	// Public API
	return {
		onGeometryLoad: onGeometryLoad,
		selectByGUID: selectByGUID,
		isMappingLoading: isMappingLoading,
		isLinkedElement: isLinkedElement,
		isHostElement: isHostElement,
		getBaseDbId: getBaseDbId,
		getLinkedDbId: getLinkedDbId,
		getAecData: getAecData,
		getMapping: getMapping,
		getDbIdInfo: getDbIdInfo
	};
	
})();