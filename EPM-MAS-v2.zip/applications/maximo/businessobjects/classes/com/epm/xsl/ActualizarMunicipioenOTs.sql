Update maximo.woserviceaddress
set slxmunicipio='05837'
where wonum ='1901632' and siteid = '0133_DE';

Commit;

Update maximo.woserviceaddress
set slxmunicipio='05440'
where wonum ='1896634' and siteid = '0133_DE';

Commit;

Update maximo.woserviceaddress
set slxmunicipio='05697'
where wonum ='1896827' and siteid = '0133_DE';

Commit;

Update maximo.woserviceaddress
set slxmunicipio='05857'
where wonum ='1901525' and siteid = '0133_DE';

Commit;

