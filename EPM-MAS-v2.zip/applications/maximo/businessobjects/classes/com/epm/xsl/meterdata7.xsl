<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/">
    <xsl:text>&#xa;</xsl:text>  <!-- new line -->
    <UpdateMXMETERDATA xmlns="http://www.ibm.com/maximo">
        <MXMETERDATASet>
            <xsl:apply-templates/>
        </MXMETERDATASet>
    </UpdateMXMETERDATA>
</xsl:template>
<xsl:template match="*/*/*/max:METERDATA">
    <METERDATA xmlns="http://www.ibm.com/maximo">
        <SITEID><xsl:value-of select="max:SITEID"/></SITEID>
        <ASSETNUM><xsl:value-of select="max:ASSETNUM"/></ASSETNUM>
        <METERNAME><xsl:value-of select="max:METERNAME"/></METERNAME>
        <REMARKS><xsl:value-of select="max:REMARKS"/></REMARKS>
        <STARTMEASURE><xsl:value-of select="max:STARTMEASURE"/></STARTMEASURE>
        <ENDMEASURE><xsl:value-of select="max:ENDMEASURE"/></ENDMEASURE>
        <NEWREADING><xsl:value-of select="max:NEWREADING"/></NEWREADING>
        <NEWREADINGDATE><xsl:value-of select="max:NEWREADINGDATE"/></NEWREADINGDATE>
    </METERDATA>
</xsl:template>

</xsl:stylesheet>