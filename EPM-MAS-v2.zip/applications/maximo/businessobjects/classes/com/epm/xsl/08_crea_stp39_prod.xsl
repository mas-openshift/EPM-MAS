<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://EPM.BizTalk.TrabajosProgramados.Schemas.CrearTP.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <xsl:variable name="supervisor" select="max:PERSON[max:PERSONID=../max:SUPERVISOR]"/>
        <xsl:variable name="lead" select="max:PERSON[max:PERSONID=../max:LEAD]"/>
        <xsl:variable name="logged" select="max:PERSON[max:PERSONID=../max:MAXUSER/max:PERSONID]"/>
        <xsl:variable name="reportedby" select="max:PERSON[max:PERSONID=../max:REPORTEDBY]"/>
        <epm:CrearTPRequest>
            <!--<AplicacionOrigen>EAM</AplicacionOrigen>-->
            <AplicacionOrigen>MAXIMO</AplicacionOrigen>     <!-- pedido por Angela 29-06-2017 -->
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
            <!-- Cambio H�ctor 20 feb '18 -->
            <IDSolicitud><xsl:value-of select="max:WONUM"/></IDSolicitud>
            <xsl:choose>
                <xsl:when test="max:SLXFSM=1">
                    <!-- Cambio H�ctor 20 feb '18 -->
                    <!--<IDSolicitud><xsl:value-of select="max:SLXFSMNUM"/></IDSolicitud>-->
                    <NumeroTarea>
                        <xsl:if test="max:SLXMULTITAREA=1"><xsl:value-of select="max:WOSEQUENCE"/></xsl:if>
                        <xsl:if test="max:SLXMULTITAREA=0">1</xsl:if>
                    </NumeroTarea>
                </xsl:when>
                <xsl:otherwise>
                    <!-- Cambio H�ctor 20 feb '18 -->
                    <!--<IDSolicitud><xsl:value-of select="max:WONUM"/></IDSolicitud>-->
                    <NumeroTarea>1</NumeroTarea>
                </xsl:otherwise>
            </xsl:choose>
            <TipoTarea>
			    <!-- Carlos G�mez 24 Mar '21 Mejora unificaci�n de flujo de Lineales-->
                <xsl:if test="max:SLXTIPOTRABAJOPO = 1">PROYE</xsl:if>
                <xsl:if test="max:SLXTIPOTRABAJOPO = 2">PROYE</xsl:if>
                <xsl:if test="max:SLXTIPOTRABAJOPO = 3">MP</xsl:if>
                <xsl:if test="max:SLXTIPOTRABAJOPO = 4">PROYE</xsl:if>
			</TipoTarea>
            <xsl:for-each select="max:WORKORDER[max:SLXMULTITAREA=1]">
                <Tareas>
                    <!-- Cambio H�ctor 20 feb '18 -->
                    <IDSolicitud><xsl:value-of select="max:WORKTYPE"/></IDSolicitud> 
                    <!--<IDSolicitud><xsl:value-of select="max:SLXFSMNUM"/></IDSolicitud>--> 
                    <NumeroTarea><xsl:value-of select="max:WOSEQUENCE"/></NumeroTarea>
                </Tareas>
            </xsl:for-each>
            <RequiereFSM><xsl:value-of select="translate(max:SLXFSM,'10','SN')"/></RequiereFSM>
            <ActivoUbicacion>	
                <!-- pedido por Angela 30-06-2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o, si esta no tuviera, la ubicaci�n del activo de la OT) -->
               
                <!-- MCE-57 Edita por Jesus Uzcategui 22-05-2020-->

                <!-- Comentado debido a Mejora 134
                <xsl:variable name="woactivitypr1" select="max:WOACTIVITY[max:PLUSDPREREQTYPE='1']"/>
                <xsl:variable name="woactivitypr2" select="max:WOACTIVITY[max:PLUSDPREREQTYPE='2']"/>

                <xsl:choose>
                    <xsl:when test="$woactivitypr1/max:LOCATIONS/max:SLXALIAS!=''">
                        <xsl:value-of select="$woactivitypr1/max:LOCATIONS/max:SLXALIAS"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="$woactivitypr2/max:LOCATIONS/max:SLXALIAS"/>
                    </xsl:otherwise>
                </xsl:choose>
                -->
                
                <!-- Mejora 134 Junio '22 javalos -->
                <xsl:if test="max:WOACTIVITY">
                    <xsl:value-of select="max:WOACTIVITY/max:LOCATIONS/max:SLXALIAS"/>
                </xsl:if>
                <xsl:if test="not(max:WOACTIVITY)">
                    <xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>
                </xsl:if>

            </ActivoUbicacion>
            <xsl:if test="max:WOSERVICEADDRESS/max:SLXDEPART!=''">
                <Departamento><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXDEPART"/></Departamento>
            </xsl:if>
            <xsl:if test="max:WOSERVICEADDRESS/max:SLXMUNICIPIO!=''">
                <Municipio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXMUNICIPIO"/></Municipio>
            </xsl:if>
            <TipoDireccion><xsl:value-of select="max:LOCATIONS/max:SLXURBANORURAL"/></TipoDireccion>
            <!--<Barrio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXBARRIO"/></Barrio>   SM: no lo tenemos -->
            <Barrio>1</Barrio>   <!-- pedido por Angela 29-06-2017 -->
            <Vereda>
                <xsl:if test="max:SLXVEREDA=''">0</xsl:if>
                <xsl:if test="max:SLXVEREDA!=''"><xsl:value-of select="max:SLXVEREDA"/></xsl:if>
            </Vereda>
            <xsl:if test="max:SLXTIPOTRABAJOPO!=''">
                <TipoTrabajo><xsl:value-of select="max:SLXTIPOTRABAJOPO"/></TipoTrabajo>
            </xsl:if>
            <Direccion><xsl:value-of select="max:WOSERVICEADDRESS/max:FORMATTEDADDRESS"/></Direccion>
            <!-- Aparentemente dej� de funcionar dp. de homologaci�n! -->
            <!--<CedulaSolicitante><xsl:value-of select="max:MAXUSER/max:PERSONID"/></CedulaSolicitante>      persona logueada (relaci�n SLXLOGGEDINPERSON) -->
            <!--
            <NombreSolicitante><xsl:value-of select="$logged/max:DISPLAYNAME"/></NombreSolicitante>
            <CedulaSolicitante><xsl:value-of select="max:MAXUSER/max:PERSONID"/></CedulaSolicitante>     <!- C�dula (PERSONID) del usuario conectado  ->
            <TelefonoSolicitante><xsl:value-of select="$logged/max:PRIMARYPHONE"/></TelefonoSolicitante>
			-->
		
            <NombreSolicitante><xsl:value-of select="$reportedby/max:DISPLAYNAME"/></NombreSolicitante>
            <CedulaSolicitante><xsl:value-of select="max:REPORTEDBY"/></CedulaSolicitante>     <!-- C�dula (PERSONID) del usuario conectado  -->
            <TelefonoSolicitante><xsl:value-of select="$reportedby/max:PRIMARYPHONE"/></TelefonoSolicitante>
            <GrupoResponsable><xsl:value-of select="$reportedby/max:SLXCENACTDESC"/></GrupoResponsable>  <!-- C Gomez M068 -05-08-2021  -->
            <IDTrabajoPadre><xsl:value-of select="max:PARENT"/></IDTrabajoPadre>  <!-- C Gomez M068 -05-08-2021  -->			
            <Observacion><xsl:value-of select="max:SLXSTPCOMENTARIOS"/></Observacion>
            <NombreInterventor><xsl:value-of select="$lead/max:DISPLAYNAME"/></NombreInterventor>
            <CedulaInterventor><xsl:value-of select="max:LEAD"/></CedulaInterventor>            
            <TelefonoInterventor><xsl:value-of select="$lead/max:PRIMARYPHONE"/></TelefonoInterventor>
            <NombreResponsable><xsl:value-of select="$supervisor/max:DISPLAYNAME"/></NombreResponsable>
            <CedulaResponsable><xsl:value-of select="max:SUPERVISOR"/></CedulaResponsable>
            <TelefonoResponsable><xsl:value-of select="$supervisor/max:PRIMARYPHONE"/></TelefonoResponsable>
            <xsl:if test="max:TARGSTARTDATE!=''">
                <FechaProbableInicio><xsl:value-of select="max:TARGSTARTDATE"/></FechaProbableInicio>
            </xsl:if>
            <xsl:if test="max:TARGCOMPDATE!=''">
                <FechaProbableFin><xsl:value-of select="max:TARGCOMPDATE"/></FechaProbableFin>
            </xsl:if>
            <ReqLineaViva><xsl:value-of select="translate(max:SLXINCTRBLV,'10','SN')"/></ReqLineaViva>
            <CedulaLineaCuadrilla>  <!-- pedido por Angela 24-07-2017 -->
                <!--<xsl:if test="max:SLXINCTRBLV='1'"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>-->
                <xsl:value-of select="max:SLXLIDLINVIVA"/>
            </CedulaLineaCuadrilla>
						
			<!-- Inclir campo nuevo EPM_STPRADICADONUM (numero radicado) Angela Casta�o 20/07/2020 -->
			<RadCliente><xsl:value-of select="max:EPM_STPRADICADONUM"/></RadCliente>
			<!--NumRadicado><xsl:value-of select="max:EPM_STPRADICADONUM"/></NumRadicado>-->
			
            
			<!--RadCliente></RadCliente>-->
            <ReqManiobras><xsl:value-of select="translate(max:SLXREQMANIOBRAS,'10','SN')"/></ReqManiobras>
            <ReqCambioRed><xsl:value-of select="translate(max:SLXREQCAMBRED,'10','SN')"/></ReqCambioRed>
            <ReqSuspension><xsl:value-of select="translate(max:SLXREQSUSPCL,'10','SN')"/></ReqSuspension>
            <DesAclaracionesAvisos><xsl:value-of select="max:SLXACLAVISO"/></DesAclaracionesAvisos>
            <DesDetalleDireccion></DesDetalleDireccion>
            <UsrCreacion><xsl:value-of select="max:MAXUSER/max:LOGINID"/></UsrCreacion>     <!-- Login del usuario conectado -->
			
			
			<!-- Cambio Angela 20 feb '18 -->
            <Descripcion><xsl:value-of select="max:REASONFORCHANGE"/></Descripcion>
            <DescripcionDetallada><xsl:value-of select="max:REASONFORCHANGE_LONGDESCRIPTION"/></DescripcionDetallada>
            <!--<Descripcion><xsl:value-of select="max:DESCRIPTION"/></Descripcion>
            <DescripcionDetallada><xsl:value-of select="max:DESCRIPTION_LONGDESCRIPTION"/></DescripcionDetallada>-->
            <xsl:for-each select="max:WOACTIVITY">
                <xsl:sort select="max:TASKID"/>     <!-- Edison orden� a petici�n de Angela -->
                <Pasos>
                    <NumeroOrden><xsl:value-of select="max:TASKID"/></NumeroOrden>
                    <!--<TipPasoOrdenPrograma><xsl:apply-templates select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>-->
                    <xsl:if test="max:PLUSDPREREQTYPE!=''">
                        <TipPasoOrdenPrograma><xsl:value-of select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>
                    </xsl:if>
                    <CodigoElemento>	
                        <!-- pedido por Angela 30-06-2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                        <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                        <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o, si esta no tuviera, la ubicaci�n del activo de la OT) -->
                       <!--<xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>-->
                        <!-- pedido por Angela 17 JUL 18 -->
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>
                    </CodigoElemento>
                    <!-- Nueva regla de Angela 24 Agosto '17 -->
                    <xsl:if test="max:PLUSDPREREQTYPE='1'">
                        <xsl:if test="max:PLUSDAGENCY!=''">
                            <IdeAccion><xsl:value-of select="max:PLUSDAGENCY"/></IdeAccion>
                        </xsl:if>
                    </xsl:if>
                    <NomFases>
                        <xsl:if test="max:SLXFASER = '1'">R</xsl:if>
                        <xsl:if test="max:SLXFASES = '1'">S</xsl:if>
                        <xsl:if test="max:SLXFASET = '1'">T</xsl:if>
                    </NomFases>
                    
					<!-- <DesDireccionElemento><xsl:value-of select="max:LOCATIONS/max:DESCRIPTION"/></DesDireccionElemento>-->
					
					<!-- Nueva regla de Angela 24 Agosto '17 -->
                    <xsl:if test="max:PLUSDPREREQTYPE='1'">
                        <xsl:if test="max:SCHEDSTART!=''">
                            <FecEstimadaEjecucion><xsl:value-of select="max:SCHEDSTART"/></FecEstimadaEjecucion>
                        </xsl:if>
                    </xsl:if>
                    <DesPaso><xsl:value-of select="max:DESCRIPTION"/></DesPaso>     <!-- SM: "Solo para maniobras" -->
                    <NombreResponsable><xsl:value-of select="max:SLXRESPMAN"/></NombreResponsable>
                    <DesDireccionElemento><xsl:value-of select="max:WOSERVICEADDRESS/max:FORMATTEDADDRESS"/></DesDireccionElemento>		<!-- C Gomez M068 -05-08-2021  -->			
                </Pasos>
            </xsl:for-each>
            <xsl:for-each select="max:DOCLINKS">
                <Adjuntos>
                    <Nombre><xsl:value-of select="max:DOCUMENT"/></Nombre>
                    <Ruta><xsl:value-of select="max:WEBURL"/></Ruta>
                </Adjuntos>
            </xsl:for-each>
            <NombreContacto><xsl:value-of select="$supervisor/max:DISPLAYNAME"/></NombreContacto>
            <TelefonoContacto><xsl:value-of select="$supervisor/max:PRIMARYPHONE"/></TelefonoContacto>
            <CoordenadaX><xsl:value-of select="max:WOSERVICEADDRESS/max:LONGITUDEX"/></CoordenadaX>
            <CoordenadaY><xsl:value-of select="max:WOSERVICEADDRESS/max:LATITUDEY"/></CoordenadaY>
			
			<!-- Incluir N�mero de la STP en la informaci�n enviada en la STP Angela 19/04/2021  -->
			<NumeroTP><xsl:value-of select="max:SLXSTPNUM"/></NumeroTP>
			<!-- Incluir compensacliente en la informaci�n enviada en la STP Angela 30/04/2021  -->
			<CompensaCliente><xsl:value-of select="max:EPM_STPCOMPCLIENTE"/></CompensaCliente>
            <!-- Nombre del usuario conectado Angela Casta�o 24/05/2021 RP-PEI-0081-->
			<NombreUsrCreacion><xsl:value-of select="$logged/max:DISPLAYNAME"/></NombreUsrCreacion> 

				
        </epm:CrearTPRequest>
    </xsl:template>
</xsl:stylesheet>