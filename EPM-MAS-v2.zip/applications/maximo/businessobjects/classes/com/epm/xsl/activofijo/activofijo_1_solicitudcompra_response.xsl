<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xslt="http://xml.apache.org/xslt" xmlns:ns0="http://ProcurementManager.Schemas.ProcessPurchaseOrderResponse" exclude-result-prefixes="xslt ns0">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/ns0:ProcessPurchaseOrderResponse/Header">
    <xsl:text>&#xa;</xsl:text>   <!-- Enter -->
    <max:InvokeJDEASSETPRResponse xmlns:max="http://www.ibm.com/maximo">
        <max:JDEASSETPRSet>
            <max:SLXASSETPR action="Change">
                <max:SLXEXTSYSNUMS>
                    <max:OWNERTABLE>SLXASSETPR</max:OWNERTABLE>
                    <max:OWNERID><!-- se llena por script! --></max:OWNERID>    <xsl:comment>Llenado por script!</xsl:comment>
                    <max:DOCUMENTLINENUMBER><xsl:value-of select="Detail/PurchaseOrderLineNumber"/></max:DOCUMENTLINENUMBER>
                    <max:PURCHASEORDERLINENUMBER><xsl:value-of select="Detail/PurchaseOrderLineNumber"/></max:PURCHASEORDERLINENUMBER>
                    <max:DOCUMENTNUMBER><xsl:value-of select="DocumentNumber"/></max:DOCUMENTNUMBER>
                    <max:DOCUMENTCOMPANY><xsl:value-of select="DocumentCompany"/></max:DOCUMENTCOMPANY>
                    <max:DOCUMENTTYPECODE><xsl:value-of select="DocumentTypeCode"/></max:DOCUMENTTYPECODE>
                </max:SLXEXTSYSNUMS>
            </max:SLXASSETPR>
        </max:JDEASSETPRSet>
    </max:InvokeJDEASSETPRResponse>
</xsl:template>
</xsl:stylesheet>