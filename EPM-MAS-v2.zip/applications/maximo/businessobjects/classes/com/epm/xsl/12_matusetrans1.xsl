<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <xsl:variable name="operation">
            <xsl:choose>
                <xsl:when test="starts-with(local-name(*[1]), 'Update')">Update</xsl:when>
                <xsl:when test="starts-with(local-name(*[1]), 'Create')">Create</xsl:when>
                <xsl:otherwise>Sync</xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        <xsl:element namespace="http://www.ibm.com/maximo" name="{concat('max:',$operation,'MXINVISSUE')}">
            <max:MXINVISSUESet>
                <xsl:apply-templates/>
            </max:MXINVISSUESet>
        </xsl:element>
    </xsl:template>
    <xsl:template match="max:MATUSETRANS">
        <max:MATUSETRANS>
            <max:TOSITEID><xsl:value-of select="../max:SITEID"/></max:TOSITEID>
            <max:REFWO><xsl:value-of select="../max:WONUM"/></max:REFWO>
            <max:OWNERSYSID>FSM</max:OWNERSYSID>
            <xsl:for-each select="*">
                <xsl:element name="{concat('max:',local-name(.))}">
                    <xsl:value-of select="."/>
                </xsl:element>
            </xsl:for-each>
        </max:MATUSETRANS>
    </xsl:template>
</xsl:stylesheet>