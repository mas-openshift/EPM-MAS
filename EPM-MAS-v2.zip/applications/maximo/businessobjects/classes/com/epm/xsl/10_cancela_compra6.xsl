<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <xsl:variable name="doc_no" select="max:SLXAUXMIF_NP"/>
    <xsl:variable name="firstLine" select="(max:WPITEM|max:MRLINE)[max:SLXEXTSYSNUMS/max:DOCUMENTNUMBER=$doc_no][1]"/>
    <xsl:variable name="persnrespns" select="$firstLine/max:PERSON[max:PERSONID=$firstLine/max:SLXRESPJDE]"/>
    <xsl:variable name="centractvd" select="$persnrespns/max:SLXCENACT"/>
    <xsl:variable name="almcnble" select="$firstLine/max:SLXALMACENABLE"/>
    <proc:ProcessPurchaseOrderRequest>
        <Header>
            <ApprovalRouteCode><xsl:value-of select="substring($centractvd, string-length($centractvd)-3)"/></ApprovalRouteCode>
            <BusinessUnit>
                <xsl:if test="$almcnble=1"><xsl:value-of select="$firstLine/max:SLXALMACEN"/></xsl:if>
                <xsl:if test="$almcnble=0"><xsl:value-of select="$persnrespns/max:SLXCENACT"/></xsl:if>
            </BusinessUnit>
            <Company><xsl:value-of select="$firstLine/max:ORGID"/></Company>
            <xsl:for-each select="(max:WPITEM|max:MRLINE)[max:SLXEXTSYSNUMS/max:DOCUMENTNUMBER=$doc_no]">
                <Detail>
                    <ActionType>D</ActionType>
                    <OriginalOrderLineKey>
                        <DocumentCompany><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTCOMPANY"/></DocumentCompany>
                        <DocumentLineNumber><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTLINENUMBER"/></DocumentLineNumber>
                        <DocumentNumber><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTNUMBER"/></DocumentNumber>
                        <DocumentSuffix/>   <!-- no va -->
                        <DocumentTypeCode><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTTYPECODE"/></DocumentTypeCode>
                    </OriginalOrderLineKey>
                    <!-- Piden agregar esta sección, se agrega igual que en la creación -->
                    <Product>
                        <Description1><xsl:value-of select="substring(max:DESCRIPTION, 0, 31)"/></Description1>
                        <Description2><xsl:value-of select="substring(max:SLXDESCRIPCION2, 0, 31)"/></Description2>
                        <Item>
                            <ItemCatalog></ItemCatalog>
                            <ItemFreeForm></ItemFreeForm>
                            <ItemId><xsl:value-of select="max:ITEMNUM"/></ItemId>
                            <ItemProduct></ItemProduct>
                            <ItemSupplier></ItemSupplier>
                        </Item>
                    </Product>
                </Detail>
            </xsl:for-each>
            <Processing>
                <ActionType>3</ActionType>
                <ProcessingVersion>EPMP070</ProcessingVersion>  <!-- valor para ORGID = EPM -->
            </Processing>
        </Header>
    </proc:ProcessPurchaseOrderRequest>
</xsl:template>
</xsl:stylesheet>