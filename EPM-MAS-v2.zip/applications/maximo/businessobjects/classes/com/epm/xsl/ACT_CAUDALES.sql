USE [Aguas]
declare @fechaInicial DATE, @fechaFinal DATE

set @fechaInicial ='2018-04-11'
Set @fechaFinal ='2018-04-12'

	SELECT E.idempresa AS Empresa
		,CAP.senal AS Senal
		,(
			CASE 
				WHEN CAST(CS.CampoInterno AS VARCHAR(50)) = 'medidorEntradaHora'
					THEN CAD.medidorEntradaHora
				WHEN CAST(CS.CampoInterno AS VARCHAR(50)) = 'medidorSalida1Hora'
					THEN CAD.medidorSalida1Hora
				END
			) AS Valor
		,BE.fecha AS FechaRegistro
		,A.fecha AS FechaCambio
		,'' AS Observaciones
		,1 AS IdProceso
	FROM ROP.CaudalesEncabezados BE
	INNER JOIN ROP.Plantas P ON BE.idPlanta = P.idPlanta
	INNER JOIN ROP.Empresas E ON P.idEmpresa = E.idEmpresa
	INNER JOIN ROP.Caudales CAD ON P.idPlanta = BE.idPlanta
	INNER JOIN ROP.CamposAdministradoresPlantas CAP ON P.idPlanta = CAP.idPlanta
	INNER JOIN ROP.Senales S ON CAP.Senal = S.Senal
	INNER JOIN ROP.CamposSenales CS ON CAP.idCampoSenal = CS.idCampo
		AND CS.idTabla = (SELECT idTabla
		FROM [ROP].[TablasSenales]
		WHERE Descripcion = 'Caudales')
	LEFT JOIN ROP.Auditorias A ON P.idPlanta = A.idPlanta
		AND A.tablaFuente = 'Caudales'
		AND A.idAccion = 2
	WHERE S.Estado = 1
		AND A.idAuditoria IN (
			SELECT MAX(AD.idAuditoria)
			FROM ROP.AuditoriasDetalles AD
			INNER JOIN ROP.Auditorias AA ON AD.idAuditoria = AA.idAuditoria
			WHERE cast(AD.clavePrimaria AS XML).value('(/clavePrimaria//campo//valor/node())[1]', 'INT') = CAD.idCaudal
				AND AA.idAccion = 2
				AND AA.tablaFuente = 'Caudales'
				AND CONVERT(VARCHAR(10), AA.fecha, 110) BETWEEN CONVERT(VARCHAR(10), @fechaInicial, 110)
					AND CONVERT(VARCHAR(10), @fechaFinal, 110)
			)
		AND CONVERT(VARCHAR(10), A.fecha, 110) BETWEEN CONVERT(VARCHAR(10), @fechaInicial, 110)
			AND CONVERT(VARCHAR(10), @fechaFinal, 110)
	ORDER BY P.idPlanta
