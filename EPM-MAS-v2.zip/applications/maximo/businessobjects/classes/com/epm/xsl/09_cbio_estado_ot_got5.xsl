<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.NotificarEstadoOT" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:NotificarEstadoOT>
            <SistemaOrigen>MAXIMO</SistemaOrigen>
            <SistemaDestino><xsl:value-of select="max:SOURCESYSID"/></SistemaDestino>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <EstadoMaximo><xsl:value-of select="max:STATUS"/></EstadoMaximo>
            <FechaEstado><xsl:value-of select="max:STATUSDATE"/></FechaEstado>
            <OT_Maximo><xsl:value-of select="max:WONUM"/></OT_Maximo>
            <OT_Externa><xsl:value-of select="max:EXTERNALREFID"/></OT_Externa>
            <!-- 
            Cambios OCT '19 
            
            "En el estado de la OT 'CANCELADA', en el campo Observaciones se debe 
            enviar=  'motivo de no realizaci�n (WORKORDER.SLXMOTIVORECH)' y debe 
            ser obligatorio como est� hoy. Para todos los ESTADOS de la OT, ( ya 
            no solo para los estados 'COMPNOREALIZADA' y 'EJECUTADO') en el campo 
            Observaciones se debe enviar= WORKORDER.SLXMOTIVORECH + 
            WORKLOG.DESCRIPTION_LONGDESCRIPTION, para los dos �ltimos se lleva la 
            informaci�n del �ltimo registro del WORKLOG.LOGTYPE = 'CIERREOT' que 
            se encuentra en la pesta�a de Registro de la Orden de trabajo".
            -->
            <!--
            <Observaciones>
                <xsl:choose>
                    <xsl:when test="max:STATUS='CANCELADA'">
                        <xsl:value-of select="max:SLXMOTIVORECH"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="concat(max:SLXMOTIVORECH,' ',max:WORKLOG[max:LOGTYPE='CIERREOT' and not(../max:WORKLOG[max:LOGTYPE='CIERREOT']/max:WORKLOGID > max:WORKLOGID)]/max:DESCRIPTION_LONGDESCRIPTION)"/>
                    </xsl:otherwise>
                </xsl:choose>
            </Observaciones>
            -->
            <Observaciones><xsl:value-of select="concat(max:SLXMOTIVORECH,' ',max:WORKLOG/max:DESCRIPTION_LONGDESCRIPTION)"/></Observaciones>
            <xsl:if test="max:STATUS='COMPNOREALIZADA' or max:STATUS='CANCELADA'">
                <CausaNoRealizacion><xsl:value-of select="max:SLXMOTNOREAL"/></CausaNoRealizacion>
            </xsl:if>
        </epm:NotificarEstadoOT>
    </xsl:template>
</xsl:stylesheet>