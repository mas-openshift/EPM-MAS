<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:act="http://Activos.Schemas.RequestCrearActivosProyectos" exclude-result-prefixes="xslt xsl max">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <act:RequestCrearActivosProyectos>
        <Empresa><xsl:value-of select="max:SLXTRASLOPER[1]/max:ORGID"/></Empresa>
        <FechaTraslado><xsl:value-of select="substring(max:SLXTRASLOPER[1]/max:CREATEDATE,1,10)"/></FechaTraslado>
        <Simulacion><xsl:value-of select="max:SLXTRASLOPER[1]/max:SIMULAR"/></Simulacion>
        <PreActivos>
            <!--<xsl:for-each select="max:SLXTRASLOPER/max:ASSET">-->
            <xsl:for-each select="max:SLXTRASLOPER[generate-id()=generate-id(key('assetjd',max:SLXPREACTIVO)[1])]">
                <act:PreActivo>
                    <Numero><xsl:value-of select="max:SLXPREACTIVO"/></Numero>
                    <CentroActividad><xsl:value-of select="max:ASSET/max:LOCATIONS/max:SLXCENTROACTIVIDAD"/></CentroActividad>
                    <UnidadDeNegocio><xsl:value-of select="max:ASSET/max:GLACCOUNT/max:GLCOMP[@glorder='0']"/></UnidadDeNegocio>
                    <CuentaObjeto><xsl:value-of select="max:ASSET/max:GLACCOUNT/max:GLCOMP[@glorder='1']"/></CuentaObjeto>
                    <CuentaAuxiliar><xsl:value-of select="max:ASSET/max:GLACCOUNT/max:GLCOMP[@glorder='2']"/></CuentaAuxiliar>
                    <IdEstructuraClase><xsl:value-of select="max:ASSET/max:CLASSSTRUCTUREID"/></IdEstructuraClase>
                    <VidaUtilMeses><xsl:value-of select="max:ASSET/max:SLXVIDAFINACT"/></VidaUtilMeses>
                    <JustificacionCambioVidaUtil><!-- nulo seg�n documento --></JustificacionCambioVidaUtil>
                </act:PreActivo>
            </xsl:for-each>
        </PreActivos>
    </act:RequestCrearActivosProyectos>
</xsl:template>
</xsl:stylesheet>