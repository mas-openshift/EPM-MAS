<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas_Eam" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    
    <xsl:template match="/*/*/*[1]">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:OrdenesTrabajo>
            <Operacion>CancelacionOT</Operacion>
            <OrdenTrabajo>
                <epm:InformacionOrdenTrabajo>
                    <General>
                        <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
                        <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
                        <Wonum><xsl:value-of select="max:WONUM"/></Wonum>
                        <TipoTarea><xsl:value-of select="max:SLXTIPOTAREA"/></TipoTarea>     <!-- puede ser: INSPSUBESTINTER, MTTOELEMREDAEREA, PODAMANRESVEG seg�n correo de Claudia -->
                        <Secuencia>
                            <xsl:value-of select="max:WOSEQUENCE"/>
                            <xsl:if test="max:WOSEQUENCE=''">1</xsl:if>
                        </Secuencia>
                        <CodTipoTrabajo><xsl:value-of select="max:WORKTYPE"/></CodTipoTrabajo>
                        <TipoServicio><xsl:value-of select="max:SLXTIPOSERVICIO"/></TipoServicio>
                        <GrupoResponsable><xsl:value-of select="max:SLXGRRESP"/></GrupoResponsable>     <!-- H�ctor lo pide por correo para que integrador diferencie si es FSM o FSE. -->
                    </General>
                </epm:InformacionOrdenTrabajo>
            </OrdenTrabajo>
        </epm:OrdenesTrabajo>
    </xsl:template>

</xsl:stylesheet>