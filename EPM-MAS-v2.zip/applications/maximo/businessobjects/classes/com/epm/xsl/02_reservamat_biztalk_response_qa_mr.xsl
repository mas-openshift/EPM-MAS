<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ns0="http://EPM.Materiales.BizTalk.Schemas.MaximoSoliciudMaterialesResponse" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*">
    <xsl:text>&#xa;</xsl:text>  <!-- new line -->
    <max:InvokeERPRESERVAResponse>
        <max:ERPRESERVASet>
            <max:WORKORDER action="Change">
                <max:SLXAUXMIF_NP><xsl:value-of select="OTERP"/></max:SLXAUXMIF_NP>
                <max:MR action="Change">
                    <xsl:for-each select="ListaMateriales">
                        <max:MRLINE action="Change">
                            <max:WPITEMID><xsl:value-of select="SecuenciaItemMaterial"/></max:WPITEMID>
                            <max:SLXEXTSYSNUMS>
                                <max:OWNERTABLE>MRLINE</max:OWNERTABLE>
                                <max:OWNERID><xsl:value-of select="SecuenciaItemMaterial"/></max:OWNERID>
                                <max:ORDERNUMBER><xsl:value-of select="../OTERP"/></max:ORDERNUMBER>
                                <max:UNIQUEKEYIDENTIFIER><xsl:value-of select="ClaveUnicaSecuenciaMaterialERP"/></max:UNIQUEKEYIDENTIFIER>
                            </max:SLXEXTSYSNUMS>
                        </max:MRLINE>
                    </xsl:for-each>
                </max:MR>
            </max:WORKORDER>
        </max:ERPRESERVASet>
    </max:InvokeERPRESERVAResponse>
</xsl:template>
</xsl:stylesheet>