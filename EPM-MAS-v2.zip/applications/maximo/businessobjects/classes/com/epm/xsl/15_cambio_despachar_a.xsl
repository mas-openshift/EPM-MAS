<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://EPM.Materiales.BizTalk.Schemas.MaximoSolicitudMaterialesRequest" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <epm:MaximoSolicitudMaterialesRequest>
        <SistemaOrigen>MAXIMO</SistemaOrigen>
        <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
        <TipoDocumento><xsl:value-of select="max:TIPODOC"/></TipoDocumento>
        <OTERP><xsl:value-of select="max:ORDERNUMBER"/></OTERP>
        <TipoAccionEjecutar>C</TipoAccionEjecutar>
        <Cliente><xsl:value-of select="max:DESPACHARADESTINO"/></Cliente>
    </epm:MaximoSolicitudMaterialesRequest>
</xsl:template>
</xsl:stylesheet>