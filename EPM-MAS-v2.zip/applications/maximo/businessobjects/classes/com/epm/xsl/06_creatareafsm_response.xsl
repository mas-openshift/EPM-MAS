<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ns0="http://Epm.Biztalk.GestorOT.Schemas_CA" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <max:InvokeFSMWOTAREAResponse>
        <max:FSMWOTAREASet>
            <max:WORKORDER action="Change">
                <max:SLXFSMNUM><xsl:value-of select="*/*/CallID"/></max:SLXFSMNUM>
                <max:SLXFSMSTATUS><xsl:value-of select="*/*/Status"/></max:SLXFSMSTATUS>
                <max:SLXFSMDATE><xsl:value-of select="*/*/FechaEnvio"/></max:SLXFSMDATE>
            </max:WORKORDER>
        </max:FSMWOTAREASet>
    </max:InvokeFSMWOTAREAResponse>
</xsl:template>
</xsl:stylesheet>