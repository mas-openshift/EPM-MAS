<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ora="http://oracle.e1.bssv.JP571301/" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest" exclude-result-prefixes="xslt max ora proc">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <proc:ProcessPurchaseOrderRequest>
        <Header>
            <OriginApplication>MAXIMO</OriginApplication>
            <ProcessReference>CompraActivos</ProcessReference>
            <Company><xsl:value-of select="max:ORGID"/></Company>
            <!--<ApprovalRouteCode><xsl:value-of select="max:PERSON/max:SLXCENACT"/></ApprovalRouteCode>-->
            <ApprovalRouteCode><xsl:value-of select="substring(max:PERSON/max:SLXCENACT, string-length(max:PERSON/max:SLXCENACT)-3)"/></ApprovalRouteCode>
            <BusinessUnit><xsl:value-of select="max:PERSON/max:SLXCENACT"/></BusinessUnit>
            <ChangeOrderNumber/>
            <CurrencyCodeFrom><xsl:value-of select="max:CONTRACT/max:CURRENCYCODE"/></CurrencyCodeFrom>
            <!--Zero or more repetitions:-->
            <Detail>
                <ActionType>A</ActionType>
                <BusinessUnit></BusinessUnit>
                <CostUnitPurchasing><xsl:value-of select="max:COSTOAPROX"/></CostUnitPurchasing>
                <FinancialDetail>
                    <AssetId><xsl:value-of select="max:NUMPREACTIVO"/></AssetId>
                    <GlAccount>
                        <BusinessUnit><xsl:value-of select="max:SLXUNIDNEGOCIO"/></BusinessUnit>
                        <ObjectAccount><xsl:value-of select="max:SLXCOBJETO"/></ObjectAccount>
                        <Subsidiary><xsl:value-of select="max:SLXCAUX"/></Subsidiary>
                    </GlAccount>
                </FinancialDetail>
                <Product>
                    <Description1><xsl:value-of select="substring(max:DESCRIPTION, 0, 31)"/></Description1>
                    <Description2></Description2>
                    <Item>
                        <ItemId><xsl:value-of select="max:ITEMNUM"/></ItemId>
                    </Item>
                </Product>
                <QuantityOrdered><xsl:value-of select="count(max:SLXASSETPRLINE)"/></QuantityOrdered>
                <ShipTo>
                    <EntityTaxId><xsl:value-of select="max:ORGID"/></EntityTaxId>
                </ShipTo>
                <UserReservedNumber>1</UserReservedNumber>     <!-- n� de l�nea de la solicitud -->
                <!--<TransactionOriginator><xsl:value-of select="../max:PERSON/max:PERSONID"/></TransactionOriginator>-->
                <TransactionOriginator><xsl:value-of select="max:PERSON/max:PERSONID"/></TransactionOriginator>
                <OriginalOrderLineKey>
                    <DocumentCompany><!-- lo pone el Integrador (equivalencia con la Planta) -->
                        <xsl:value-of select="max:SITEID"/>
                    </DocumentCompany>
                    <!--<DocumentLineNumber/>-->
                    <DocumentNumber><xsl:value-of select="max:CONTRACTREFNUM"/></DocumentNumber>
                    <!--<DocumentSuffix/>-->
                    <DocumentTypeCode><!-- del doc: Campo extra en contrato para identificar el tipo. Lista de valores (PDEF); Lina indica que son solo 2 valores: OG y 04 -->
                        <xsl:value-of select="max:CONTRACT/max:SLXTYPECODEJDE"/>
                    </DocumentTypeCode>
                </OriginalOrderLineKey>
            </Detail>
            <Processing>
                <ActionType>1</ActionType>
            </Processing>
            <ShipToAddress>
                <ShipTo>
                    <EntityTaxId><xsl:value-of select="max:ORGID"/></EntityTaxId>
                </ShipTo>
            </ShipToAddress>
            <SupplierAddress>
                <Supplier>
                    <EntityId><xsl:value-of select="max:CONTRACT/max:VENDOR"/></EntityId>
                </Supplier>
            </SupplierAddress>
            <SupplierSO><xsl:value-of select="max:ASSETPRNUM"/></SupplierSO>
            <Reference><xsl:value-of select="max:SITEID"/></Reference>
        </Header>
    </proc:ProcessPurchaseOrderRequest>
</xsl:template>
</xsl:stylesheet>