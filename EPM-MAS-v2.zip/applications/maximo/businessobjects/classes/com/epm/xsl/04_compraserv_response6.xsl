<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xslt="http://xml.apache.org/xslt" xmlns:ns0="http://ProcurementManager.Schemas.ProcessPurchaseOrderResponse" exclude-result-prefixes="xslt ns0">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/ns0:ProcessPurchaseOrderResponse/Header">
    <xsl:text>&#xa;</xsl:text>   <!-- Enter -->
    <max:InvokeERPCOMPRAResponse xmlns:max="http://www.ibm.com/maximo">
        <max:ERPCOMPRASet>
            <max:WORKORDER action="Change">
                <!--<max:SLXAUXMIF_NP><xsl:value-of select="DocumentNumber"/></max:SLXAUXMIF_NP>-->
                <max:SLXAUXMIF_NP><xsl:value-of select="Detail[1]/BusinessUnit"/>|<xsl:value-of select="DocumentCompany"/>|<xsl:value-of select="DocumentNumber"/>|<xsl:value-of select="DocumentTypeCode"/></max:SLXAUXMIF_NP>
                <!--<max:DESCRIPTION_LONGDESCRIPTION><xsl:value-of select="ns0:ProcessPurchaseOrderResponse/ErrorMessage"/></max:DESCRIPTION_LONGDESCRIPTION>-->
                <xsl:for-each select="Detail">
                    <max:WPITEM action="Change">
                        <max:WPITEMID><!-- se llena por script! --></max:WPITEMID>
                        <max:SLXEXTSYSNUMS>
                            <max:OWNERID><!-- se llena por script! --></max:OWNERID>
                            <max:OWNERTABLE>WPITEM</max:OWNERTABLE>
                            <max:DOCUMENTLINENUMBER><xsl:value-of select="PurchaseOrderLineNumber"/></max:DOCUMENTLINENUMBER>
                            <max:PURCHASEORDERLINENUMBER><xsl:value-of select="PurchaseOrderLineNumber"/></max:PURCHASEORDERLINENUMBER>
                            <max:DOCUMENTNUMBER><xsl:value-of select="../DocumentNumber"/></max:DOCUMENTNUMBER>
                            <max:DOCUMENTCOMPANY><xsl:value-of select="../DocumentCompany"/></max:DOCUMENTCOMPANY>
                            <max:DOCUMENTTYPECODE><xsl:value-of select="../DocumentTypeCode"/></max:DOCUMENTTYPECODE>
                        </max:SLXEXTSYSNUMS>
                    </max:WPITEM>
                </xsl:for-each>
            </max:WORKORDER>
        </max:ERPCOMPRASet>
    </max:InvokeERPCOMPRAResponse>
</xsl:template>
</xsl:stylesheet>