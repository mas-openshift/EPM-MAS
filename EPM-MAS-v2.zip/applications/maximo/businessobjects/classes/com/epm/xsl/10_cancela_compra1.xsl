<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <xsl:variable name="vendor" select="max:SLXAUXMIF_NP"/>
    <proc:ProcessPurchaseOrderRequest>
        <Header>
            <ApprovalRouteCode><xsl:value-of select="max:PERSON/max:SLXCENACT"/></ApprovalRouteCode>
            <BusinessUnit><xsl:value-of select="max:WPITEM[max:VENDOR = $vendor][1]/max:SLXUNIDNEGOCIO"/></BusinessUnit>
            <xsl:for-each select="max:WPITEM[max:VENDOR = $vendor]">
                <Detail>
                    <ActionType>D</ActionType>
                    <OriginalOrderLineKey>
                        <DocumentCompany><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTCOMPANY"/></DocumentCompany>
                        <DocumentLineNumber><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTLINENUMBER"/></DocumentLineNumber>
                        <DocumentNumber><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTNUMBER"/></DocumentNumber>
                        <!--<DocumentSuffix></DocumentSuffix>-->
                        <DocumentTypeCode><xsl:value-of select="max:SLXEXTSYSNUMS/max:DOCUMENTTYPECODE"/></DocumentTypeCode>
                    </OriginalOrderLineKey>
                </Detail>
            </xsl:for-each>
            <Processing>
                <ActionType>3</ActionType>
                <ProcessingVersion>EPMP070</ProcessingVersion>  <!-- valor para ORGID = EPM -->
            </Processing>
        </Header>
    </proc:ProcessPurchaseOrderRequest>
</xsl:template>
</xsl:stylesheet>