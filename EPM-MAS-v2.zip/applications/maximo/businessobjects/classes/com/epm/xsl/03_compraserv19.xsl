<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ora="http://oracle.e1.bssv.JP571301/" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest" exclude-result-prefixes="xslt max ora proc">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- (Enter) -->
    <!--<xsl:variable name="vendor" select="substring-before(max:SLXAUXMIF_NP, '|')"/>-->
    <xsl:variable name="ot_jde" select="max:SLXAUXMIF_NP"/>
    <xsl:variable name="firstLine" select="(max:WPITEM|max:MRLINE)[max:SLXENVIARJDE_XSL='1'][1]"/>
    <xsl:variable name="almcnble" select="$firstLine/max:SLXALMACENABLE"/>
    <xsl:variable name="mayrctia" select="$firstLine/max:SLXMAYORCUANTIA"/>
    <xsl:variable name="persnrespns" select="$firstLine/max:PERSON[max:PERSONID=$firstLine/max:SLXRESPJDE]"/>
    <xsl:variable name="persnrecibe" select="$firstLine/max:PERSON[max:PERSONID=$firstLine/max:SLXENVIARA]"/>
    <xsl:variable name="centractvd" select="$persnrespns/max:SLXCENACT"/>
    <proc:ProcessPurchaseOrderRequest>
        <Header>
            <OriginApplication>MAXIMO</OriginApplication>
            <ProcessReference>Compras</ProcessReference>
            <Company>EPM</Company>
            <ApprovalRouteCode><xsl:value-of select="substring($centractvd, string-length($centractvd)-3)"/></ApprovalRouteCode>
            <BusinessUnit>
                <xsl:if test="$almcnble=1"><xsl:value-of select="$firstLine/max:SLXALMACEN"/></xsl:if>
                <xsl:if test="$almcnble=0"><xsl:value-of select="$persnrespns/max:SLXCENACT"/></xsl:if>
            </BusinessUnit>
            <ChangeOrderNumber/>
            <CurrencyCodeFrom>
                <xsl:if test="$firstLine/max:SLXCONTRACTNUM=''">COP</xsl:if>
                <xsl:if test="$firstLine/max:SLXCONTRACTNUM!=''"><xsl:value-of select="$firstLine/max:CONTRACT/max:CURRENCYCODE"/></xsl:if>
            </CurrencyCodeFrom>
            <Store>
                <xsl:if test="$almcnble=1">true</xsl:if>
                <xsl:if test="$almcnble=0">false</xsl:if>
            </Store>
            <AmountLess>
                <xsl:if test="$mayrctia=0">true</xsl:if>
                <xsl:if test="$mayrctia=1">false</xsl:if>
            </AmountLess>
            <MediaObject>
                <xsl:for-each select="max:DOCLINKS[max:DOCTYPE='ANEXOS COMPRA']">
                    <MoItems>
                        <ItemName><xsl:value-of select="max:WEBURL"/></ItemName>
                    </MoItems>
                </xsl:for-each>
            </MediaObject>
            <!--Zero or more repetitions:-->
            <xsl:for-each select="(max:WPITEM|max:MRLINE)[max:SLXENVIARJDE_XSL='1']">
                <Detail>
                    <ActionType>A</ActionType>
                    <BusinessUnit></BusinessUnit>
                    <CostUnitPurchasing><xsl:value-of select="max:UNITCOST"/></CostUnitPurchasing>
                    <FinancialDetail>
                        <AssetId><xsl:value-of select="(../max:ASSET|../max:WORKORDER/max:ASSET)/max:SLXJD"/></AssetId>
                        <GlAccount>
                            <BusinessUnit><xsl:value-of select="max:SLXUNIDNEGOCIO"/></BusinessUnit>
<!--                            <ObjectAccount>
                                <xsl:if test="max:LINETYPE='SERVICE' or max:LINETYPE='STDSERVICE'"><xsl:value-of select="max:SLXCOBJETO"/></xsl:if>
                                <xsl:if test="max:LINETYPE='ITEM' or max:LINETYPE='MATERIAL'"><xsl:value-of select="max:SLXMAPCTAS/max:SLXGLCUENTAOBJETO"/></xsl:if>
                            </ObjectAccount>-->
                            <ObjectAccount><xsl:value-of select="max:SLXCOBJETO"/></ObjectAccount>
                            <Subsidiary><xsl:value-of select="max:SLXCAUX"/></Subsidiary>
                        </GlAccount>
                        <GlClassCode></GlClassCode>
                        <Subledger><xsl:value-of select="$ot_jde"/></Subledger>
                        <SubledgerTypeCode>W</SubledgerTypeCode>
                    </FinancialDetail>
                    <OriginalOrderLineKey>
                        <DocumentCompany><xsl:value-of select="max:SITEID"/></DocumentCompany>  <!-- supongo que es el mismo de la OT -->
                        <DocumentLineNumber></DocumentLineNumber>
                        <DocumentNumber><xsl:value-of select="max:SLXCONTRACTNUM"/></DocumentNumber>
                        <DocumentSuffix></DocumentSuffix>
                        <DocumentTypeCode><xsl:value-of select="max:SLXCONTRACT/max:SLXTYPECODEJDE"/></DocumentTypeCode>
                    </OriginalOrderLineKey>
                    <Product>
                        <Description1><xsl:value-of select="substring(max:DESCRIPTION, 0, 31)"/></Description1>
                        <Description2><xsl:value-of select="substring(max:SLXDESCRIPCION2, 0, 31)"/></Description2>
                        <Item>
                            <ItemCatalog></ItemCatalog>
                            <ItemFreeForm></ItemFreeForm>
                            <ItemId><xsl:value-of select="max:ITEMNUM"/></ItemId>
                            <ItemProduct></ItemProduct>
                            <ItemSupplier></ItemSupplier>
                        </Item>
                    </Product>
                    <QuantityOrdered><xsl:value-of select="max:ITEMQTY|max:QTY"/></QuantityOrdered>
                    <ShipTo>
                        <EntityId></EntityId>
                        <EntityLongId></EntityLongId>
                        <EntityTaxId>
                            <xsl:if test="max:LINETYPE='MATERIAL' or max:LINETYPE='ITEM'"><xsl:value-of select="max:LOCATIONS/max:SLXNIT_ALMACEN"/></xsl:if>
                            <xsl:if test="max:LINETYPE='SERVICE' or max:LINETYPE='STDSERVICE'"><xsl:value-of select="max:SLXENVIARA"/></xsl:if>
                        </EntityTaxId>
                    </ShipTo>
                    <TransactionOriginator><xsl:value-of select="max:SLXRESPJDE"/></TransactionOriginator>
                    <TaskCode>
                        <xsl:if test="name()='WPITEM'"><xsl:value-of select="max:WONUM"/></xsl:if>
                        <xsl:if test="name()='MRLINE'"><xsl:value-of select="max:REFWO"/></xsl:if>
                    </TaskCode>
                    <UserReservedNumber><xsl:value-of select="max:MRLINENUM"/></UserReservedNumber>
                    <MediaObject>
                        <xsl:for-each select="max:DOCLINKS[max:DOCTYPE='ANEXOS COMPRA']">
                            <MoItems>
                                <ItemName><xsl:value-of select="max:WEBURL"/></ItemName>
                            </MoItems>
                        </xsl:for-each>
                    </MediaObject>
                    <LineType>
                        <xsl:if test="max:LINETYPE='ITEM'">IT</xsl:if>
                        <xsl:if test="max:LINETYPE='MATERIAL'">MA</xsl:if>
                        <xsl:if test="max:LINETYPE='SERVICE'">SE</xsl:if>
                        <xsl:if test="max:LINETYPE='STDSERVICE'">ST</xsl:if>
                    </LineType>
                    <wpItemId><xsl:value-of select="max:WPITEMID|max:MRLINEID"/></wpItemId>
                </Detail>
            </xsl:for-each>
            <Processing>
                <ActionType>1</ActionType>
                <ProcessingVersion>EPM430014</ProcessingVersion>    <!-- orden tipo 'OR' (no 'OW') -->
            </Processing>
            <ShipToAddress>
                <ShipTo>
                    <EntityId></EntityId>
                    <EntityLongId></EntityLongId>
                    <EntityTaxId>
                        <xsl:if test="$firstLine/max:LINETYPE='MATERIAL' or $firstLine/max:LINETYPE='ITEM'"><xsl:value-of select="$firstLine/max:LOCATIONS/max:SLXNIT_ALMACEN"/></xsl:if>
                        <xsl:if test="$firstLine/max:LINETYPE='SERVICE' or $firstLine/max:LINETYPE='STDSERVICE'"><xsl:value-of select="$firstLine/max:SLXENVIARA"/></xsl:if>
                    </EntityTaxId>
                </ShipTo>
            </ShipToAddress>
            <SupplierAddress>
                <Supplier>
                    <EntityId><xsl:value-of select="$firstLine/max:VENDOR"/></EntityId>
                    <EntityLongId></EntityLongId>
                    <EntityTaxId></EntityTaxId>
                </Supplier>
            </SupplierAddress>
            <SupplierSO><xsl:value-of select="max:MRNUM"/></SupplierSO>
            <Reference><xsl:value-of select="../max:MR/max:SITEID"/></Reference>    <!-- Solo enviar si es MR -->
        </Header>
    </proc:ProcessPurchaseOrderRequest>
</xsl:template>
</xsl:stylesheet>