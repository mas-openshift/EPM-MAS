<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:act="http://Activos.Schemas.TrasladoOperacionRequest" exclude-result-prefixes="xslt xsl max">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>

<!--<xsl:key name="assetjd" match="max:ASSET" use="max:SLXJD" />-->
<xsl:key name="assetjd" match="max:SLXTRASLOPER" use="max:ASSET/max:SLXJD" />

<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <act:TrasladoOperacionRequest>
        <Empresa><xsl:value-of select="max:SLXTRASLOPER[1]/max:ORGID"/></Empresa>
        <!--<Preactivo><xsl:value-of select="max:SLXTRASLOPER[1]/max:ASSET/max:SLXPREACTIVO"/></Preactivo>       �o debe ser el de la OT? -->
        <Preactivo><xsl:value-of select="max:SLXTRASLOPER[1]/max:SLXPREACTIVO"/></Preactivo>
        <FechaTraslado><xsl:value-of select="substring(max:SLXTRASLOPER[1]/max:CREATEDATE,1,10)"/></FechaTraslado>
        <Simulacion><xsl:value-of select="max:SLXTRASLOPER[1]/max:SIMULAR"/></Simulacion>
        <Activos>
            <!-- 
            Agrupar por SLXJD 
            
            El for-each ..[generate-id()=generate-id(key(...))] itera por el 1er.
            nodo que coincide con el valor que se le da a la llave en esa iteraci�n.
            Me parece que el for-each va nodo por nodo evaluando la condici�n; como 
            la llave est� definida fuera del for-each, en alg�n momento de la iteraci�n
            el nodo coincidir� con el primero de cada grupo.
            
            La funci�n generate-id() devuelve un string �nico que identifica al nodo.
            La funci�n key() devuelve el(los) nodo(s) para el valor de acuerdo a la 
            llave definida por 'key'.
            
            -->
            <xsl:for-each select="max:SLXTRASLOPER[generate-id()=generate-id(key('assetjd',max:ASSET/max:SLXJD)[1])]">
                <!-- contiene el grupo para esta llave -->
                <xsl:variable name="groupByJD" select="key('assetjd', max:ASSET/max:SLXJD)"/>
                <!--<COUNT><xsl:value-of select="count($groupByJD)"/></COUNT>-->
                <Activo>
                    <NumeroActivo><xsl:value-of select="max:ASSET/max:SLXJD"/></NumeroActivo>
                    <MontoDistribuir><!-- ? --></MontoDistribuir>
                    <PorcentajeDistribuir><xsl:value-of select="round(sum($groupByJD/max:PCTJEDISTRIB) * 100) div 100"/></PorcentajeDistribuir>
                    <ObjetoCosto><xsl:value-of select="max:ASSET/max:SLXOBJCOSTEO"/></ObjetoCosto>
                    <VidaUtilMeses><!-- nulo seg�n documento --></VidaUtilMeses>
                    <JustificacionCambioVidaUtil></JustificacionCambioVidaUtil>
                </Activo>
            </xsl:for-each>
        </Activos>
    </act:TrasladoOperacionRequest>
</xsl:template>
</xsl:stylesheet>