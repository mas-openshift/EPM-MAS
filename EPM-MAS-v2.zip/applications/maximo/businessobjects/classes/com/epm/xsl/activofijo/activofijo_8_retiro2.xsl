<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:act="http://Activos.Schemas.RetirarActivosPuntuales" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" exclude-result-prefixes="max xsi xsl xslt" >
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <act:RetirarActivosPuntuales>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Fecha><xsl:value-of select="max:STATUSDATE"/></Fecha>
            <Activos>
                <!--Zero or more repetitions:-->
                <act:Activo>
                    <!--<Numero><xsl:value-of select="max:ASSETNUM"/></Numero>-->
                    <Numero><xsl:value-of select="max:SLXJD"/></Numero>
                    <Estado><xsl:value-of select="max:STATUS"/></Estado>
                    <Anexo><xsl:value-of select="max:DOCLINKS[max:DOCTYPE='ANEXO BAJAS']/max:WEBURL"/></Anexo>
                </act:Activo>
            </Activos>
        </act:RetirarActivosPuntuales>
    </xsl:template>
</xsl:stylesheet>