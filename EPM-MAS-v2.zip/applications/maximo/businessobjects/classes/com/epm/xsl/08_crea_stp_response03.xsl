<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns0="http://EPM.BizTalk.TrabajosProgramados.Schemas.CrearTP.CrearTPResponse">
<xsl:output method="xml" indent="yes"/>
<xsl:template match="/">
    <max:InvokeMARWOCREASTPResponse xmlns:max="http://www.ibm.com/maximo">
        <max:MARWOCREASTPSet>
            <max:WORKORDER action="Change">
                <max:SLXSTPNUM><xsl:value-of select="ns0:CrearTPResponse/NumeroDeTP"/></max:SLXSTPNUM>
            </max:WORKORDER>
        </max:MARWOCREASTPSet>
    </max:InvokeMARWOCREASTPResponse>
</xsl:template>
</xsl:stylesheet>