<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas_Eam" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    
    <xsl:key name="tipoDocKey" match="max:WPITEM[max:LINETYPE='ITEM' and max:DIRECTREQ=0 and max:SLXAUXMIF_NP!='']" use="max:SLXEXTSYSNUMS/max:ORDERNUMBER"/>
    
    <xsl:template match="/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        
        <epm:OrdenesTrabajo>
            <Operacion>CreacionOT</Operacion>
            <OrdenTrabajo>
                <xsl:choose>
                    <xsl:when test="max:WORKORDER/max:SLXMULTITAREA='0'">
                        <xsl:apply-templates select="max:WORKORDER[max:SLXMULTITAREA='0']" mode="main"/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:apply-templates select="max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][1]" mode="main"/>
                        <TareasMultiEtapa>
                            <xsl:for-each select="max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][position()>1]">
                                <RelacionDependencia>
                                    <TipoRelacion><xsl:value-of select="max:WOTASKRELATION[1]/max:RELTYPE"/></TipoRelacion>
                                    <!--<Secuencia><xsl:value-of select="max:WOSEQUENCE"/></Secuencia>-->
                                    <xsl:variable name="predwonum" select="max:WOTASKRELATION[1]/max:PREDWONUM"/>
                                    <Secuencia><xsl:value-of select="//max:WORKORDER[max:WONUM=$predwonum]/max:WOSEQUENCE"/></Secuencia>
                                    <!--<NumeroOrdenPadre><xsl:value-of select="max:PREDESSORWOS"/></NumeroOrdenPadre>-->
                                    <NumeroOrdenPadre><xsl:value-of select="max:WOTASKRELATION[1]/max:PREDWONUM"/></NumeroOrdenPadre>
                                    <xsl:apply-templates select="."/>
                                </RelacionDependencia>
                            </xsl:for-each>
                        </TareasMultiEtapa>
                    </xsl:otherwise>
                </xsl:choose>
            </OrdenTrabajo>
            
            <!-- CC99 Alumbrado: ojo, se repite el choose de arriba -->
            <xsl:choose>
                <xsl:when test="max:WORKORDER/max:SLXMULTITAREA='0'">
                    <xsl:apply-templates select="max:WORKORDER[max:SLXMULTITAREA='0']" mode="alum"/>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:apply-templates select="max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][1]" mode="alum"/>
                </xsl:otherwise>
            </xsl:choose>
            
        </epm:OrdenesTrabajo>
    </xsl:template>
    
    
    <xsl:template match="max:WORKORDER" mode="main">
        <epm:InformacionOrdenTrabajo>
            <General>
                <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
                <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
                <Wonum><xsl:value-of select="max:WONUM"/></Wonum>
                <TipoTarea><xsl:value-of select="max:SLXTIPOTAREA"/></TipoTarea>     <!-- puede ser: INSPSUBESTINTER, MTTOELEMREDAEREA, PODAMANRESVEG seg�n correo de Claudia -->
                <Prioridad><xsl:value-of select="max:WOPRIORITY"/></Prioridad>
                <ObservacionesSolicitud>
                    <ObservacionSolicitud><xsl:value-of select="concat(max:DESCRIPTION, ' ', max:DESCRIPTION_LONGDESCRIPTION)"/></ObservacionSolicitud>
                </ObservacionesSolicitud>
                <FechaCreacion><xsl:value-of select="max:REPORTDATE"/></FechaCreacion>
                <!-- Ma�a del servicio; debe ir atributo "nil" si es nulo, si no, se cae -->
                <FechaVencimiento>
                    <xsl:if test="not(max:FNLCONSTRAINT) or max:FNLCONSTRAINT=''"><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:if>
                    <xsl:value-of select="max:FNLCONSTRAINT"/>
                </FechaVencimiento>
                <!-- Ma�a del servicio; debe ir atributo "nil" si es nulo, si no, se cae -->
                <FechaInicioTemprano>
                    <xsl:if test="not(max:SNECONSTRAINT) or max:SNECONSTRAINT=''"><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:if>
                    <xsl:value-of select="max:SNECONSTRAINT"/>
                </FechaInicioTemprano>
                <FechaInicioTardio xsi:nil="true"></FechaInicioTardio>
                <IndicadorOnline>false</IndicadorOnline>
                <Secuencia>
                    <xsl:value-of select="max:WOSEQUENCE"/>
                    <xsl:if test="max:WOSEQUENCE=''">1</xsl:if>
                </Secuencia>
                <Duracion><xsl:value-of select="substring-before(max:ESTDUR, '.')"/></Duracion>
                <CodTipoTrabajo><xsl:value-of select="max:WORKTYPE"/></CodTipoTrabajo>
                <!-- Javier y JC Mej�a piden cambiarlo 19 Feb '18
                <NumeroSTP><xsl:value-of select="max:SLXSTPNUM"/></NumeroSTP>
                <RequiredSTP><xsl:value-of select="max:SLXSTP"/></RequiredSTP>-->
                <NumeroSTP></NumeroSTP>
                <RequiredSTP>false</RequiredSTP>
                <CallID></CallID>
                <TipoServicio><xsl:value-of select="max:SLXTIPOSERVICIO"/></TipoServicio>
                <!-- 
                    Paso a Prod 28 Mayo
                    Se comenta esta l�nea porque es parte del CC108 y ese no pas�
                    por eso este archivo se deja con �ndice "19b" y no "19".
                -->
                <!--<GrupoResponsable><xsl:value-of select="max:SLXGRRESP"/></GrupoResponsable>-->     <!-- CC 108 (Cambio versi�n FSM a FSE) --> 
                <RutaAprobacion/> <!-- Claudia lo pidi� vac�o -->
            </General>
            <Direccion>
                <xsl:apply-templates select="max:WOSERVICEADDRESS"/>
            </Direccion>
            <Infraestructura>
                <DescripcionUbicacion><xsl:value-of select="max:LOCATIONS/max:DESCRIPTION"/></DescripcionUbicacion>
                <IdentificadorUbicacion><xsl:value-of select="max:LOCATION"/></IdentificadorUbicacion>
                <DescripcionActivo><xsl:value-of select="max:ASSET/max:DESCRIPTION"/></DescripcionActivo>
                <IdentificadorActivo><xsl:value-of select="max:ASSETNUM"/></IdentificadorActivo>
                <CapacidadActivo></CapacidadActivo>
            </Infraestructura>
            <Oterp>
                <xsl:for-each select="max:WPITEM[generate-id() = generate-id(key('tipoDocKey',max:SLXEXTSYSNUMS/max:ORDERNUMBER)[1])]">
                    <xsl:variable name="tipo_doc" select="max:SLXAUXMIF_NP"/>
                    <Oterp>
                        <Ot><xsl:value-of select="max:SLXEXTSYSNUMS/max:ORDERNUMBER"/></Ot>
                        <TipoDocumento><xsl:value-of select="$tipo_doc"/></TipoDocumento>
                        <MaterialesRequeridos>
                            <xsl:for-each select="key('tipoDocKey',max:SLXEXTSYSNUMS/max:ORDERNUMBER)">
                                <MaterialRequerido>
                                    <Sede><xsl:value-of select="max:STORELOCSITE"/></Sede>
                                    <Almacen><xsl:value-of select="max:LOCATION"/></Almacen>
                                    <CodMaterial><xsl:value-of select="max:ITEMNUM"/></CodMaterial>
                                    <Cantidad><xsl:value-of select="substring-before(max:ITEMQTY, '.')"/></Cantidad>
                                    <CategoriaContable></CategoriaContable>
                                    <TipoDocumento><xsl:value-of select="max:SLXAUXMIF_NP"/></TipoDocumento>
                                    <SecuenciaMaterialERP><xsl:value-of select="max:SLXEXTSYSNUMS/max:UNIQUEKEYIDENTIFIER"/></SecuenciaMaterialERP>
                                </MaterialRequerido>
                            </xsl:for-each>
                        </MaterialesRequeridos>
                    </Oterp>
                </xsl:for-each>
            </Oterp>
            <RecursosEscasos>
                <xsl:for-each select="max:WPTOOL">
                    <RecursoEscaso>
                        <TipoRecursoEscaso><xsl:value-of select="max:DESCRIPTION"/></TipoRecursoEscaso>
                    </RecursoEscaso>
                </xsl:for-each>
            </RecursosEscasos>
            <ArchivosAdjuntos>
                <xsl:for-each select="max:DOCLINKS">
                    <Adjunto>
                        <Nombre><xsl:value-of select="max:DOCUMENT"/></Nombre>
                        <Ruta><xsl:value-of select="max:WEBURL"/></Ruta>
                    </Adjunto>                    
                </xsl:for-each>
            </ArchivosAdjuntos>
        </epm:InformacionOrdenTrabajo>        
    </xsl:template>
    
    <xsl:template match="max:WOSERVICEADDRESS">
        <Pais>Colombia</Pais>
        <Departamento><xsl:value-of select="max:SLXDEPART"/></Departamento>
        <Municipio><xsl:value-of select="max:SLXMUNICIPIO"/></Municipio>
        <Barrio><xsl:value-of select="max:SLXBARRIO"/></Barrio>
        <Vereda><xsl:value-of select="max:SLXVEREDA"/></Vereda>
        <Geometria>
            <CoordenadaX><xsl:value-of select="max:LONGITUDEX"/></CoordenadaX>
            <CoordenadaY><xsl:value-of select="max:LATITUDEY"/></CoordenadaY>
        </Geometria>
        <Nomenclatura><xsl:value-of select="substring(max:FORMATTEDADDRESS, 1, 64)"/></Nomenclatura>
        <CodigoUnicoDireccion></CodigoUnicoDireccion>
        <IndicadorRural><xsl:value-of select="../max:LOCATIONS/max:SLXURBANORURAL"/></IndicadorRural>
        <Zona><xsl:value-of select="../max:ASSET/max:SLXSUBREGION2"/></Zona>
    </xsl:template>
    
    
    <!-- CC99 Alumbrado Marzo 2020-->
    <!--<xsl:template match="max:WORKORDER[max:SLXMULTITAREA='0'] | max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][1]" mode="InfoAlumbrado">-->
    <xsl:template match="max:WORKORDER" mode="alum">
        <Informacion>
            <General.>
                <DetalleOrdenTrabajo>
                    <SolicitudesEventos>
                        <SolicitudEvento>
                            <Numero></Numero>
                            <Solicitante><xsl:value-of select="max:SR/max:REPORTEDBY"/></Solicitante>
                            <Telefono><xsl:value-of select="max:SR/max:REPORTEDPHONE"/></Telefono>
                            <TipoSolicitud><xsl:value-of select="max:SR/max:CLASSSTRUCTURE/max:DESCRIPTION_CLASS"/></TipoSolicitud>
                            <DetalleSolicitud><xsl:value-of select="concat(max:SR/max:DESCRIPTION,' ',max:SR/max:DESCRIPTION_LONGDESCRIPTION)"/></DetalleSolicitud>
                            <Pagina><xsl:value-of select="max:SR/max:SLXPAGINA"/></Pagina>
                            <xsl:if test="max:ASSET/max:CLASSSTRUCTUREID = '133733001' or max:ASSET/max:CLASSSTRUCTUREID = '133733007'">
                                <Transformador><xsl:value-of select="max:ASSET/max:ASSETSPEC[max:ASSETATTRID='NODOTRAF']/max:ALNVALUE"/></Transformador>
                                <Nodo><xsl:value-of select="max:ASSET/max:ASSETSPEC[max:ASSETATTRID='NODOTRAF']/max:ALNVALUE"/></Nodo>
                                <PropietarioTransformador><xsl:value-of select="max:ASSET/max:ASSETSPEC[max:ASSETATTRID='PROPIETA']/max:ALNVALUE"/></PropietarioTransformador>
                            </xsl:if>
                        </SolicitudEvento>
                    </SolicitudesEventos>
                </DetalleOrdenTrabajo>
            </General.>
        </Informacion>    
    </xsl:template>
    
    
</xsl:stylesheet>