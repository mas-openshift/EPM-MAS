<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <max:UpdateMXMETERDATA>
            <max:MXMETERDATASet>
                <xsl:apply-templates/>
            </max:MXMETERDATASet>
        </max:UpdateMXMETERDATA>
    </xsl:template>
    <xsl:template match="max:METERDATA">
        <max:METERDATA>
            <max:SITEID><xsl:value-of select="max:SITEID"/></max:SITEID>
            <max:ASSETNUM><xsl:value-of select="max:ASSETNUM"/></max:ASSETNUM>
            <max:METERNAME><xsl:value-of select="max:METERNAME"/></max:METERNAME>
            <max:REMARKS><xsl:value-of select="max:REMARKS"/></max:REMARKS>
            <max:STARTMEASURE>10</max:STARTMEASURE>
            <max:ENDMEASURE>10</max:ENDMEASURE>
            <max:NEWREADING>101.00</max:NEWREADING>
            <max:NEWREADINGDATE>2017-03-02T02:03:00</max:NEWREADINGDATE>
        </max:METERDATA>
    </xsl:template>
</xsl:stylesheet>