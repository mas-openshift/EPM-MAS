<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns="http://www.ibm.com/maximo" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<xsl:output method="xml" version="1.0" encoding="ISO-8859-1" indent="yes" xslt:indent-amount="4"/>


<xsl:template match="/">
    <xsl:text>&#xa;</xsl:text>  <!-- new line -->
    <QueryERP_WOQ uniqueResult="0" maxItems="0" rsStart="0">
        <ERP_WOQQuery orderby="" operandMode="AND">
            <WHERE>
                <xsl:if test="*/*/max:WORKORDER/max:SITEID != ''">siteid='<xsl:value-of select="*/*/max:WORKORDER/max:SITEID"/>' and </xsl:if>
                <xsl:if test="*/*/max:WORKORDER/max:WONUM != ''">wonum='<xsl:value-of select="*/*/max:WORKORDER/max:WONUM"/>' and </xsl:if> 
                historyflag=0 and status in (select value from synonymdomain where domainid='WOSTATUS' and maxvalue in ('APPR','COMP','INPRG','WMATL','WSCH'))
            </WHERE>
        </ERP_WOQQuery>
    </QueryERP_WOQ>
</xsl:template>

<xsl:template match="text()|@*"/>   <!-- eliminar whitespace -->


</xsl:stylesheet>