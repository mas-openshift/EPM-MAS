<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.NotificarEstadoOTHidro" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:NotificacionEstadoOT>
            <General>
                <AplicacionDestino>HIDRO</AplicacionDestino>
                <AplicacionOrigen>MAXIMO</AplicacionOrigen>
                <Subsidiario><xsl:value-of select="max:ORGID"/></Subsidiario>
                <Estado>CANCELADO</Estado>
                <LineaNegocio><xsl:value-of select="max:SITEID"/></LineaNegocio>
                <FechaEstado><xsl:value-of select="max:FECHAESTADO"/></FechaEstado>
                <ResponsableEstado><xsl:value-of select="max:RESPONESTADO"/></ResponsableEstado>
                <NombreResponsableEstado><!-- Hector Herrera --></NombreResponsableEstado>
                <MotivoCancelacion></MotivoCancelacion>     <!-- N/A -->
                <IDInterrupcion><xsl:value-of select="max:MAXNUMINTERRUP"/></IDInterrupcion>
                <NumeroInterrupcion><xsl:value-of select="max:HIDRONUMINTERRUP"/></NumeroInterrupcion>
                <PermisoOperativo><xsl:value-of select="max:NUMPOPADRE"/></PermisoOperativo>
            </General>
        </epm:NotificacionEstadoOT>
    </xsl:template>
</xsl:stylesheet>