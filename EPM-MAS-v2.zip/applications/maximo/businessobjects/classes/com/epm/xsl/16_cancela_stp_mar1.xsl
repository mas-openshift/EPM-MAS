<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <xsl:variable name="supervisor" select="max:PERSON[max:PERSONID=../max:SUPERVISOR]"/>
        <epm:CrearTPRequest>
            <Observacion>Se cancela la OT nro: <xsl:value-of select="max:WONUM"/>, se requiere la cancelaci�n de la TP</Observacion>
        </epm:CrearTPRequest>
    </xsl:template>
</xsl:stylesheet>