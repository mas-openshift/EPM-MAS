<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas_Eam" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:OrdenesTrabajo>
            <Operacion>CreacionOT</Operacion>
            <OrdenTrabajo>
                <xsl:choose>
                    <xsl:when test="max:WORKORDER/max:SLXMULTITAREA='0'">
                        <xsl:apply-templates/>
                    </xsl:when>
                    <xsl:otherwise>
                        <xsl:apply-templates select="max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][1]"/>
                        <TareasMultiEtapa>
                            <xsl:for-each select="max:WORKORDER/max:WORKORDER[max:SLXMULTITAREA=1][position()>1]">
                                <RelacionDependencia>
                                    <TipoRelacion><xsl:value-of select="max:WOTASKRELATION[1]/max:RELTYPE"/></TipoRelacion>
                                    <Secuencia><xsl:value-of select="max:WOSEQUENCE"/></Secuencia>
                                    <!--<NumeroOrdenPadre><xsl:value-of select="max:PREDESSORWOS"/></NumeroOrdenPadre>-->
                                    <NumeroOrdenPadre><xsl:value-of select="max:WOTASKRELATION[1]/max:PREDWONUM"/></NumeroOrdenPadre>
                                    <xsl:apply-templates select="."/>
                                </RelacionDependencia>
                            </xsl:for-each>
                        </TareasMultiEtapa>
                    </xsl:otherwise>
                </xsl:choose>
            </OrdenTrabajo>
        </epm:OrdenesTrabajo>
    </xsl:template>
    <xsl:template match="max:WORKORDER">
        <epm:InformacionOrdenTrabajo>
            <General>
                <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
                <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
                <Wonum><xsl:value-of select="max:WONUM"/></Wonum>
                <TipoTarea><xsl:value-of select="max:SLXTIPOTAREA"/></TipoTarea>     <!-- puede ser: INSPSUBESTINTER, MTTOELEMREDAEREA, PODAMANRESVEG seg�n correo de Claudia -->
                <Prioridad><xsl:value-of select="max:WOPRIORITY"/></Prioridad>
                <ObservacionesSolicitud>
                    <ObservacionSolicitud><xsl:value-of select="concat(max:DESCRIPTION, ' ', max:DESCRIPTION_LONGDESCRIPTION)"/></ObservacionSolicitud>
                </ObservacionesSolicitud>
                <FechaCreacion><xsl:value-of select="max:REPORTDATE"/></FechaCreacion>
                <!-- Ma�a del servicio; debe ir atributo "nil" si es nulo, si no, se cae -->
                <FechaVencimiento>
                    <xsl:if test="not(max:FNLCONSTRAINT) or max:FNLCONSTRAINT=''"><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:if>
                    <xsl:value-of select="max:FNLCONSTRAINT"/>
                </FechaVencimiento>
                <!-- Ma�a del servicio; debe ir atributo "nil" si es nulo, si no, se cae -->
                <FechaInicioTemprano>
                    <xsl:if test="not(max:SNECONSTRAINT) or max:SNECONSTRAINT=''"><xsl:attribute name="xsi:nil">true</xsl:attribute></xsl:if>
                    <xsl:value-of select="max:SNECONSTRAINT"/>
                </FechaInicioTemprano>
                <FechaInicioTardio xsi:nil="true"></FechaInicioTardio>
                <IndicadorOnline>false</IndicadorOnline>
                <Secuencia>1</Secuencia>    <!-- �de d�nde se obtiene? -->
                <Duracion><xsl:value-of select="substring-before(max:ESTDUR, '.')"/></Duracion>
                <CodTipoTrabajo><xsl:value-of select="max:WORKTYPE"/></CodTipoTrabajo>
                <NumeroSTP><xsl:value-of select="max:SLXSTPNUM"/></NumeroSTP>
                <RequiredSTP><xsl:value-of select="max:SLXSTP"/></RequiredSTP>
                <CallID></CallID>
                <TipoServicio><xsl:value-of select="max:SLXTIPOSERVICIO"/></TipoServicio>
            </General>
            <Direccion>
                <xsl:apply-templates select="max:WOSERVICEADDRESS"/>
            </Direccion>
            <Infraestructura>
                <DescripcionUbicacion><xsl:value-of select="max:LOCATION/max:DESCRIPTION"/></DescripcionUbicacion>
                <IdentificadorUbicacion><xsl:value-of select="max:LOCATION"/></IdentificadorUbicacion>
                <DescripcionActivo><xsl:value-of select="max:ASSET/max:DESCRIPTION"/></DescripcionActivo>
                <IdentificadorActivo><xsl:value-of select="max:ASSETNUM"/></IdentificadorActivo>
                <CapacidadActivo></CapacidadActivo>
            </Infraestructura>
            <Oterp>
                <xsl:for-each select="max:TIPOS_DOC/max:TIPO_DOC">
                    <xsl:variable name="tipodoc" select="."/>
                    <Oterp>
                        <Ot><xsl:value-of select="../../max:WPMATERIAL[max:SLXAUXMIF_NP = $tipodoc]/max:SLXEXTSYSNUMS/max:ORDERNUMBER"/></Ot>
                        <TipoDocumento><xsl:value-of select="."/></TipoDocumento>
                        <MaterialesRequeridos>
                            <xsl:for-each select="../../max:WPMATERIAL[max:SLXAUXMIF_NP = $tipodoc]">
                                <MaterialRequerido>
                                    <Sede><xsl:value-of select="max:STORELOCSITE"/></Sede>
                                    <Almacen><xsl:value-of select="max:LOCATION"/></Almacen>
                                    <CodMaterial><xsl:value-of select="max:ITEMNUM"/></CodMaterial>
                                    <Cantidad><xsl:value-of select="substring-before(max:ITEMQTY, '.')"/></Cantidad>
                                    <CategoriaContable></CategoriaContable>
                                    <TipoDocumento><xsl:value-of select="max:SLXAUXMIF_NP"/></TipoDocumento>
                                    <SecuenciaMaterialERP><xsl:value-of select="max:SLXEXTSYSNUMS/max:UNIQUEKEYIDENTIFIER"/></SecuenciaMaterialERP>
                                </MaterialRequerido>
                            </xsl:for-each>
                        </MaterialesRequeridos>
                    </Oterp>
                </xsl:for-each>
            </Oterp>
            <ArchivosAdjuntos>
                <xsl:apply-templates select="max:DOCLINKS"/>
            </ArchivosAdjuntos>
        </epm:InformacionOrdenTrabajo>        
    </xsl:template>
    <xsl:template match="max:WOSERVICEADDRESS">
        <Pais>Colombia</Pais>
        <Departamento><xsl:value-of select="max:SLXDEPART"/></Departamento>
        <Municipio><xsl:value-of select="max:SLXMUNICIPIO"/></Municipio>
        <Barrio><xsl:value-of select="max:SLXBARRIO"/></Barrio>
        <Vereda><xsl:value-of select="max:SLXVEREDA"/></Vereda>
        <Geometria>
            <CoordenadaX><xsl:value-of select="max:LONGITUDEX"/></CoordenadaX>
            <CoordenadaY><xsl:value-of select="max:LATITUDEY"/></CoordenadaY>
        </Geometria>
        <Nomenclatura><xsl:value-of select="substring(max:FORMATTEDADDRESS, 1, 64)"/></Nomenclatura>
        <CodigoUnicoDireccion></CodigoUnicoDireccion>
        <IndicadorRural>1</IndicadorRural>        
    </xsl:template>
    <xsl:template match="max:DOCLINKS">
        <Adjunto>
            <Nombre><xsl:value-of select="max:DOCUMENT"/></Nombre>
            <Ruta><xsl:value-of select="max:URLNAME"/></Ruta>
        </Adjunto>
    </xsl:template>
</xsl:stylesheet>