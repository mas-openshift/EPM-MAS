<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <xsl:variable name="operation">
            <xsl:choose>
                <xsl:when test="starts-with(local-name(*[1]), 'Update')">Update</xsl:when>
                <xsl:when test="starts-with(local-name(*[1]), 'Create')">Create</xsl:when>
                <xsl:otherwise>Sync</xsl:otherwise>
            </xsl:choose>
        </xsl:variable>
        <!--<max:UpdateMXMETERDATA>-->
        <xsl:element namespace="http://www.ibm.com/maximo" name="{concat('max:',$operation,'MXMETERDATA')}">
            <max:MXMETERDATASet>
                <xsl:apply-templates/>
            </max:MXMETERDATASet>
        </xsl:element>
        <!--</max:UpdateMXMETERDATA>-->
    </xsl:template>
    <xsl:template match="max:METERDATA">
        <max:METERDATA>
            <xsl:for-each select="*">
                <xsl:element name="{concat('max:',name(.))}">
                    <xsl:value-of select="."/>
                </xsl:element>
            </xsl:for-each>
        </max:METERDATA>
    </xsl:template>
</xsl:stylesheet>