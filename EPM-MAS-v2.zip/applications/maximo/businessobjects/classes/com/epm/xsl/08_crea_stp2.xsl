<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:CrearTPRequest>
            <AplicacionOrigen>EAM</AplicacionOrigen>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
            <!--<IDSolicitud></IDSolicitud>-->     <!-- Call ID no deber�a ir aqu� y lo pone el Integrador -->
            <NumeroTarea>1</NumeroTarea>
            <!--
            <xsl:for-each select="max:WOACTIVITY[max:ISTASK=0]">
                <Tareas>
                    <IDSolicitud></IDSolicitud> 
                    <NumeroTarea><xsl:value-of select="max:WOSEQUENCE"/></NumeroTarea>
                </Tareas>
            </xsl:for-each>
            -->
            <RequiereFSM><xsl:value-of select="translate(max:SLXFSM,'10','SN')"/></RequiereFSM>
            <ActivoUbicacion><xsl:value-of select="max:LOCATION"/></ActivoUbicacion>
            <Departamento><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXDEPART"/></Departamento>
            <Municipio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXMUNICIPIO"/></Municipio>
            <TipoDireccion><xsl:value-of select="max:LOCATIONS/max:SLXURBANORURAL"/></TipoDireccion>
            <Barrio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXBARRIO"/></Barrio>  <!-- SM: no lo tenemos -->
            <Vereda>
                <xsl:if test="max:SLXVEREDA=''">0</xsl:if>
                <xsl:if test="max:SLXVEREDA!=''"><xsl:value-of select="max:SLXVEREDA"/></xsl:if>
            </Vereda>
            <TipoTrabajo><xsl:value-of select="max:SLXTIPOTRABAJOPO"/></TipoTrabajo>
            <Direccion><xsl:value-of select="max:WOSERVICEADDRESS/max:FORMATTEDADDRESS"/></Direccion>
            <CedulaSolicitante><xsl:value-of select="max:REPORTEDBY"/></CedulaSolicitante>
            <CedulaInterventor><xsl:value-of select="max:REPORTEDBY"/></CedulaInterventor>
            <CedulaResponsable><xsl:value-of select="max:REPORTEDBY"/></CedulaResponsable>
            <FechaProbableInicio><xsl:value-of select="max:TARGSTARTDATE"/></FechaProbableInicio>
            <FechaProbableFin><xsl:value-of select="max:TARGCOMPDATE"/></FechaProbableFin>
            <ReqLineaViva><xsl:value-of select="translate(max:SLXINCTRBLV,'10','SN')"/></ReqLineaViva>
            <CedulaLineaCuadrilla>
                <xsl:if test="max:SLXINCTRBLV='1'"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>
            </CedulaLineaCuadrilla>
            <RadCliente></RadCliente>
            <ReqManiobras><xsl:value-of select="translate(max:SLXREQMANIOBRAS,'10','SN')"/></ReqManiobras>
            <ReqCambioRed><xsl:value-of select="translate(max:SLXREQCAMBRED,'10','SN')"/></ReqCambioRed>
            <ReqSuspension><xsl:value-of select="translate(max:SLXREQSUSPCL,'10','SN')"/></ReqSuspension>
            <DesAclaracionesAvisos><xsl:value-of select="max:SLXACLAVISO"/></DesAclaracionesAvisos>
            <DesDetalleDireccion></DesDetalleDireccion>
            <UsrCreacion><xsl:value-of select="max:REPORTEDBY"/></UsrCreacion>
            <xsl:for-each select="max:WOACTIVITY">
                <Pasos>
                    <NumeroOrden><xsl:value-of select="max:TASKID"/></NumeroOrden>   <!-- JA: �es de la OT padre o no? -->
                    <TipPasoOrdenPrograma><xsl:value-of select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>   <!-- JA: �es de la OT padre o no? -->
                    <CodigoElemento><xsl:value-of select="max:LOCATION"/></CodigoElemento>      <!-- va LOCATION y no ASSETNUM (visto en reuni�n) -->
                    <IdeAccion><xsl:value-of select="max:PLUSDAGENCY"/></IdeAccion>     <!-- JA: �es de la OT padre o no? -->
                    <NomFases>
                        <xsl:if test="max:SLXFASER = '1'">R</xsl:if>
                        <xsl:if test="max:SLXFASES = '1'">S</xsl:if>
                        <xsl:if test="max:SLXFASET = '1'">T</xsl:if>
                    </NomFases>
                    <DesDireccionElemento><xsl:value-of select="max:LOCATIONS/max:DESCRIPTION"/></DesDireccionElemento>
                    <FecEstimadaEjecucion><xsl:value-of select="max:SCHEDSTART"/></FecEstimadaEjecucion>    <!-- SM: "Solo para maniobras" -->
                    <DesPaso><xsl:value-of select="max:DESCRIPTION"/></DesPaso>     <!-- SM: "Solo para maniobras" -->
                    <NombreResponsable><xsl:value-of select="max:SLXRESPMAN"/></NombreResponsable>
                </Pasos>
            </xsl:for-each>
        </epm:CrearTPRequest>
    </xsl:template>
</xsl:stylesheet>