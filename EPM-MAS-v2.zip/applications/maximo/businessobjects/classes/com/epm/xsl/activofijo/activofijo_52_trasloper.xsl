<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:act="http://Activos.Schemas.TrasladoOperacion" exclude-result-prefixes="xslt xsl max">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <act:TrasladoOperacion>
        <Empresa><xsl:value-of select="max:SLXTRASLOPER[1]/max:ORGID"/></Empresa>
        <Preactivo><xsl:value-of select="max:SLXTRASLOPER[1]/max:ASSET/max:SLXPREACTIVO"/></Preactivo>      <!-- �o debe ser el de la OT? -->
        <FechaTraslado><xsl:value-of select="substring(max:SLXTRASLOPER[1]/max:CREATEDATE,1,10)"/></FechaTraslado>
        <Simulacion><xsl:value-of select="max:SLXTRASLOPER[1]/max:SIMULAR"/></Simulacion>
        <Activos>
            <!--Zero or more repetitions:-->
            <xsl:for-each select="max:SLXTRASLOPER/max:ASSET">
                <Activo>
                    <NumeroActivo><xsl:value-of select="max:SLXJD"/></NumeroActivo>
                    <MontoDistribuir><!-- ? --></MontoDistribuir>
                    <PorcentajeDistribuir></PorcentajeDistribuir>
                    <ObjetoCosto><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoCosto>
                    <VidaUtilMeses><!-- nulo seg�n documento --></VidaUtilMeses>
                    <JustificacionCambioVidaUtil></JustificacionCambioVidaUtil>
                </Activo>
            </xsl:for-each>
        </Activos>
    </act:TrasladoOperacion>
</xsl:template>
</xsl:stylesheet>