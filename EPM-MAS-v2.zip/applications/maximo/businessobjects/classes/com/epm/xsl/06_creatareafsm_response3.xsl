<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ns0="http://Epm.Biztalk.GestorOT.Schemas_CA" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <max:InvokeFSMWOTAREAResponse>
        <max:FSMWOTAREASet>
            <max:WORKORDER action="Change">
                <max:SLXFSMNUM><xsl:value-of select="OrdenTrabajoResponse[Number=1]/CallID"/></max:SLXFSMNUM>
                <max:SLXFSMSTATUS><xsl:value-of select="OrdenTrabajoResponse[Number=1]/Status"/></max:SLXFSMSTATUS>
                <max:SLXFSMDATE><xsl:value-of select="OrdenTrabajoResponse[Number=1]/FechaEnvio"/></max:SLXFSMDATE>
                <xsl:for-each select="OrdenTrabajoResponse">
                    <max:WORKORDER action="Change">
                        <max:SITEID>0133_DE</max:SITEID>
                        <max:WONUM><xsl:value-of select="ExternalRefID"/></max:WONUM>
                        <max:SLXFSMNUM><xsl:value-of select="CallID"/></max:SLXFSMNUM>
                        <max:SLXFSMSTATUS><xsl:value-of select="Status"/></max:SLXFSMSTATUS>
                        <max:SLXFSMDATE><xsl:value-of select="FechaEnvio"/></max:SLXFSMDATE>
                    </max:WORKORDER>
                </xsl:for-each>
            </max:WORKORDER>
        </max:FSMWOTAREASet>
    </max:InvokeFSMWOTAREAResponse>
</xsl:template>
</xsl:stylesheet>