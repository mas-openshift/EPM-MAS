<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ora="http://oracle.e1.bssv.JP571301/" xmlns:xslt="http://xml.apache.org/xslt" xmlns:proc="http://ProcurementManager.Schemas.ProcessPurchaseOrderRequest" exclude-result-prefixes="xslt max ora proc">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <xsl:variable name="vendor" select="substring-before(max:SLXAUXMIF_NP, '|')"/>
    <xsl:variable name="ot_jde" select="substring-after(max:SLXAUXMIF_NP, '|')"/>
    <proc:ProcessPurchaseOrderRequest>
        <Header>
            <OriginApplication>MAXIMO</OriginApplication>
            <ProcessReference>Compras</ProcessReference>
            <Company>EPM</Company>
            <!-- Cambiado a petici�n de Lina
            <ApprovalRouteCode><xsl:value-of select="max:SLXGRRESP"/></ApprovalRouteCode>-->
            <ApprovalRouteCode><xsl:value-of select="max:PERSON/max:SLXCENACT"/></ApprovalRouteCode>
            <!--<BusinessUnit><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='0']"/></BusinessUnit>-->
            <BusinessUnit><xsl:value-of select="(max:WPITEM|max:MRLINE)[max:VENDOR = $vendor][1]/max:SLXUNIDNEGOCIO"/></BusinessUnit>
            <ChangeOrderNumber></ChangeOrderNumber>
            <CurrencyCodeFrom>COP</CurrencyCodeFrom>
            <SupplierSO><xsl:value-of select="max:MRNUM"/></SupplierSO>
            <!--Zero or more repetitions:-->
            <xsl:for-each select="(max:WPITEM|max:MRLINE)[max:VENDOR = $vendor]">
                <Detail>
                    <ActionType>A</ActionType>
                    <BusinessUnit></BusinessUnit>
                    <CostUnitPurchasing><xsl:value-of select="max:UNITCOST"/></CostUnitPurchasing>
                    <FinancialDetail>
                        <AssetId><xsl:value-of select="(../max:ASSET|../max:WORKORDER/max:ASSET)/max:SLXJD"/></AssetId>
                        <GlAccount>
                            <!-- Se crean campos a nivel de l�nea en MAXIMO --> <!--
                            <BusinessUnit><xsl:value-of select="../max:GLACCOUNT/max:GLCOMP[@glorder='0']"/></BusinessUnit>
                            <ObjectAccount><xsl:value-of select="../max:GLACCOUNT/max:GLCOMP[@glorder='1']"/></ObjectAccount>
                            <Subsidiary><xsl:value-of select="../max:GLACCOUNT/max:GLCOMP[@glorder='2']"/></Subsidiary>-->
                            <BusinessUnit><xsl:value-of select="max:SLXUNIDNEGOCIO"/></BusinessUnit>
                            <ObjectAccount><xsl:value-of select="max:SLXCOBJETO"/></ObjectAccount>
                            <Subsidiary><xsl:value-of select="max:SLXCAUX"/></Subsidiary>
                        </GlAccount>
                        <GlClassCode></GlClassCode>
                        <Subledger><xsl:value-of select="$ot_jde"/></Subledger>
                        <SubledgerTypeCode>W</SubledgerTypeCode>
                    </FinancialDetail>
                    <!-- No va; es solo para orden con contrato
                    <OriginalOrderLineKey>
                        <DocumentCompany>00198</DocumentCompany>
                        <DocumentLineNumber></DocumentLineNumber>
                        <DocumentNumber>01034616</DocumentNumber>
                        <DocumentSuffix></DocumentSuffix>
                        <DocumentTypeCode>OG</DocumentTypeCode>
                    </OriginalOrderLineKey>
                    -->
                    <Product>
                        <Description1><xsl:value-of select="substring(max:DESCRIPTION, 0, 31)"/></Description1>
                        <Description2></Description2>
                        <Item>
                            <ItemCatalog></ItemCatalog>
                            <ItemFreeForm></ItemFreeForm>
                            <ItemId><xsl:value-of select="max:ITEMNUM"/></ItemId>
                            <ItemProduct></ItemProduct>
                            <ItemSupplier></ItemSupplier>
                        </Item>
                    </Product>
                    <QuantityOrdered><xsl:value-of select="max:ITEMQTY|max:QTY"/></QuantityOrdered>
                    <ShipTo>
                        <EntityId></EntityId>
                        <EntityLongId></EntityLongId>
                        <EntityTaxId>
                            <xsl:if test="max:LINETYPE = 'MATERIAL' and ../max:ORGID = 'EPM'">522</xsl:if>
                            <xsl:if test="max:LINETYPE != 'MATERIAL'"><xsl:value-of select="../max:PERSON/max:PERSONID"/></xsl:if>
                        </EntityTaxId>
                    </ShipTo>
                    <TransactionOriginator><xsl:value-of select="../max:PERSON/max:PERSONID"/></TransactionOriginator>
                    <TaskCode>
                        <xsl:if test="name()='WPITEM'"><xsl:value-of select="max:WONUM"/></xsl:if>
                        <xsl:if test="name()='MRLINE'"><xsl:value-of select="max:REFWO"/></xsl:if>
                    </TaskCode>
                    <UserReservedNumber>
                        <xsl:value-of select="max:MRLINENUM"/>
                    </UserReservedNumber>
                </Detail>
            </xsl:for-each>
            <Processing>
                <ActionType>1</ActionType>
                <ProcessingVersion>EPM430014</ProcessingVersion>    <!-- orden tipo 'OR' (no 'OW') -->
            </Processing>
            <ShipToAddress>
                <ShipTo>
                    <EntityId></EntityId>
                    <EntityLongId></EntityLongId>
                    <EntityTaxId><xsl:value-of select="max:PERSON/max:PERSONID"/></EntityTaxId>
                </ShipTo>
            </ShipToAddress>
            <SupplierAddress>
                <Supplier>
                    <EntityId><xsl:value-of select="$vendor"/></EntityId>
                    <EntityLongId></EntityLongId>
                    <EntityTaxId></EntityTaxId>
                </Supplier>
            </SupplierAddress>
        </Header>
    </proc:ProcessPurchaseOrderRequest>
</xsl:template>
</xsl:stylesheet>