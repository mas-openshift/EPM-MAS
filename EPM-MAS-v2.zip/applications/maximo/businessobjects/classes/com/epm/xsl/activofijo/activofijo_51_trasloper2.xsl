<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:act="http://Activos.Schemas.TrasladoOperacionRequest" exclude-result-prefixes="xslt xsl max">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>

<!--<xsl:key name="assetjd" match="max:ASSET" use="max:SLXJD" />-->
<xsl:key name="assetjd" match="max:SLXTRASLOPER" use="max:ASSET/max:SLXJD" />

<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <act:TrasladoOperacionRequest>
        <Empresa><xsl:value-of select="max:SLXTRASLOPER[1]/max:ORGID"/></Empresa>
        <!--<Preactivo><xsl:value-of select="max:SLXTRASLOPER[1]/max:ASSET/max:SLXPREACTIVO"/></Preactivo>       �o debe ser el de la OT? -->
        <Preactivo><xsl:value-of select="max:SLXTRASLOPER[1]/max:SLXPREACTIVO"/></Preactivo>
        <FechaTraslado><xsl:value-of select="substring(max:SLXTRASLOPER[1]/max:CREATEDATE,1,10)"/></FechaTraslado>
        <Simulacion><xsl:value-of select="max:SLXTRASLOPER[1]/max:SIMULAR"/></Simulacion>
        <Activos>
            <!--Zero or more repetitions:-->
<!--            <xsl:for-each select="max:SLXTRASLOPER/max:ASSET">-->
            <!-- itera por las llaves -->
            <xsl:for-each select="max:SLXTRASLOPER[generate-id()=generate-id(key('assetjd',max:ASSET/max:SLXJD)[1])]">
                <!-- contiene el grupo para esta llave -->
                <xsl:variable name="groupByJD" select="key('assetjd', max:ASSET/max:SLXJD)"/>
                <!--<COUNT><xsl:value-of select="count($groupByJD)"/></COUNT>-->
                <Activo>
                    <NumeroActivo><xsl:value-of select="max:ASSET/max:SLXJD"/></NumeroActivo>
                    <MontoDistribuir><!-- ? --></MontoDistribuir>
                    <PorcentajeDistribuir><xsl:value-of select="sum($groupByJD/max:PCTJEDISTRIB)"/></PorcentajeDistribuir>
                    <ObjetoCosto><xsl:value-of select="max:ASSET/max:SLXOBJCOSTEO"/></ObjetoCosto>
                    <VidaUtilMeses><!-- nulo seg�n documento --></VidaUtilMeses>
                    <JustificacionCambioVidaUtil></JustificacionCambioVidaUtil>
                </Activo>
            </xsl:for-each>
        </Activos>
    </act:TrasladoOperacionRequest>
</xsl:template>
</xsl:stylesheet>