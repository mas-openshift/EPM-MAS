<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:act="http://Activos.Schemas.RequestCrearActivosPuntuales" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" exclude-result-prefixes="max xsi xsl xslt" >
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>

    <xsl:template match="text()|@*">
    </xsl:template>

    <xsl:template match="/">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <act:RequestCrearActivosPuntuales>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <TipoAccionEjecutar>1</TipoAccionEjecutar>
            <Activos>
                <!--Zero or more repetitions:-->
                <xsl:apply-templates/>
            </Activos>
        </act:RequestCrearActivosPuntuales>
    </xsl:template>

    <xsl:template match="/*/*/max:ASSET">
        <act:Activo>
            <Codigo><!--nulo--></Codigo>
            <Departamento><xsl:value-of select="max:LOCATIONS/max:SLXDEPART"/></Departamento>
            <Municipio><xsl:value-of select="max:LOCATIONS/max:SLXMUNICIPIO"/></Municipio>
            <UnidadDeNegocio><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder=0]"/></UnidadDeNegocio>
            <CuentaObjeto><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder=1]"/></CuentaObjeto>
            <CuentaAuxiliar><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder=2]"/></CuentaAuxiliar>
            <MontoImpuestos></MontoImpuestos>
            <IdEstructuraClase><xsl:value-of select="max:CLASSSTRUCTUREID"/></IdEstructuraClase>
            <ObjetoDeCosto><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoDeCosto>
            <Pais>CO</Pais>
            <ActivoPadre><xsl:value-of select="max:PARENT"/></ActivoPadre>
            <CentroActividad><xsl:value-of select="max:LOCATIONS/max:SLXCENTROACTIVIDAD"/></CentroActividad>
            <FechaAdquisicion><!--nulo--></FechaAdquisicion>
            <Descripcion><xsl:value-of select="max:DESCRIPTION"/></Descripcion>
            <Descripcion1><!--nulo--></Descripcion1>
            <Descripcion2><!--nulo--></Descripcion2>
            <NumeroSerie><xsl:value-of select="max:SERIALNUM"/></NumeroSerie>
            <Estado><xsl:value-of select="max:STATUS"/></Estado>
            <NumeroUnidad><xsl:value-of select="max:ASSETNUM"/></NumeroUnidad>
            <Numero><xsl:value-of select="max:ASSETNUM"/></Numero>
            <Planta><xsl:value-of select="max:SITEID"/></Planta>
            <VidaUtilMeses><xsl:value-of select="max:SLXVIDAFINACT"/></VidaUtilMeses>
            <JustificacionCambioVidaUtil><xsl:value-of select="max:SLXJUSTIFVIDAUTIL"/></JustificacionCambioVidaUtil>
        </act:Activo>
    </xsl:template>

</xsl:stylesheet>