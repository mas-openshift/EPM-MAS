<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://EPM.Materiales.BizTalk.Schemas.MaximoSolicitudMaterialesRequest" xmlns:xslt="http://xml.apache.org/xslt" exclude-result-prefixes="xslt max epm">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <xsl:variable name="tipoDoc" select="max:SLXAUXMIF_NP"/>
    <epm:MaximoSolicitudMaterialesRequest>
        <SistemaOrigen>MAXIMO</SistemaOrigen>
        <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
        <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
        <TipoDocumento><xsl:value-of select="$tipoDoc"/></TipoDocumento>
        <Descripcion><xsl:value-of select="substring(max:MR/max:DESCRIPTION|max:DESCRIPTION, 1, 30)"/></Descripcion>
        <FechaInicio><xsl:value-of select="max:SCHEDSTART"/></FechaInicio>
        <FechaFinalizacion><xsl:value-of select="max:SCHEDFINISH"/></FechaFinalizacion>
        <CodigoAlmacen>A41</CodigoAlmacen>  <!-- para Org. EPM est� ok enviar en duro A41 -->
        <!-- Antes estos campos se obten�an de la OT
        <UnidadDeNegocio><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='0']"/></UnidadDeNegocio>
        <CuentaAuxiliar><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='2']"/></CuentaAuxiliar>
        -->
        <!-- Script llena estos campos de acuerdo al caso de que se trate (OT, MR, solo servicios) -->
        <UnidadDeNegocio><xsl:value-of select="max:AUXSCRIPT_SLXUNIDNEGOCIO"/></UnidadDeNegocio>
        <CuentaAuxiliar><xsl:value-of select="max:AUXSCRIPT_SLXCAUX"/></CuentaAuxiliar>
        <EstadoOT>40</EstadoOT>
        <ActividadCosto><xsl:value-of select="max:SLXACTCOST"/></ActividadCosto>
        <ObjetoCosto><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoCosto>
        <SolicitantePlaneador><xsl:value-of select="max:WOEQ1"/></SolicitantePlaneador> <!-- rut de quien aprueba la OT -->
        <Cliente><xsl:value-of select="*[max:ISSUETO][1]/max:ISSUETO"/></Cliente>
        <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
        <TipoAccionEjecutar>A</TipoAccionEjecutar>
        <NumeroActivo></NumeroActivo>   <!-- debe ir nulo -->
        <xsl:for-each select="(max:WPMATERIAL|max:MR/max:MRLINE)[max:SLXAUXMIF_NP=$tipoDoc]">
            <ListaMateriales>
                <CodigoAlmacenReclamar><xsl:value-of select="max:LOCATION | max:STORELOC"/></CodigoAlmacenReclamar>
                <CodigoMaterial><xsl:value-of select="max:ITEMNUM"/></CodigoMaterial>
                <SecuenciaItemMaterial><xsl:value-of select="max:WPITEMID | max:MRLINEID"/></SecuenciaItemMaterial>
                <CantidadSolicitada><xsl:value-of select="max:ITEMQTY | max:QTY"/></CantidadSolicitada>
                <FechaSolicitada><xsl:value-of select="max:REQUIREDATE"/></FechaSolicitada>
                <TipoCosto><xsl:value-of select="max:SLXTIPOCOSTO"/></TipoCosto>
                <PlantaAlmacen><xsl:value-of select="max:STORELOCSITE"/></PlantaAlmacen>
                <NumeroReserva><xsl:value-of select="max:REQUESTNUM"/></NumeroReserva>
                <TipoAccionMaterial>A</TipoAccionMaterial>
            </ListaMateriales>
        </xsl:for-each>
    </epm:MaximoSolicitudMaterialesRequest>
</xsl:template>
</xsl:stylesheet>