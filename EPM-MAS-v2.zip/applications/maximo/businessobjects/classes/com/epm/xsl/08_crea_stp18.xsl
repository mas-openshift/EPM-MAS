<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:CrearTPRequest>
            <!--<AplicacionOrigen>EAM</AplicacionOrigen>-->
            <AplicacionOrigen>MAXIMO</AplicacionOrigen>     <!-- pedido por Angela 29-06-2017 -->
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
            <xsl:choose>
                <xsl:when test="max:SLXFSM=1">
                    <IDSolicitud><xsl:value-of select="max:SLXFSMNUM"/></IDSolicitud>
                    <NumeroTarea>
                        <xsl:if test="max:SLXMULTITAREA=1"><xsl:value-of select="max:WOSEQUENCE"/></xsl:if>
                        <xsl:if test="max:SLXMULTITAREA=0">1</xsl:if>
                    </NumeroTarea>
                </xsl:when>
                <xsl:otherwise>
                    <IDSolicitud><xsl:value-of select="max:WONUM"/></IDSolicitud>
                    <NumeroTarea>1</NumeroTarea>
                </xsl:otherwise>
            </xsl:choose>
            <xsl:for-each select="max:WORKORDER[max:SLXMULTITAREA=1]">
                <Tareas>
                    <IDSolicitud><xsl:value-of select="max:SLXFSMNUM"/></IDSolicitud> 
                    <NumeroTarea><xsl:value-of select="max:WOSEQUENCE"/></NumeroTarea>
                </Tareas>
            </xsl:for-each>
            <RequiereFSM><xsl:value-of select="translate(max:SLXFSM,'10','SN')"/></RequiereFSM>
            <ActivoUbicacion>	
                <!-- pedido por Angela 30-06-2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o, si esta no tuviera, la ubicaci�n del activo de la OT) -->
                <xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>
            </ActivoUbicacion>
            <xsl:if test="max:WOSERVICEADDRESS/max:SLXDEPART!=''">
                <Departamento><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXDEPART"/></Departamento>
            </xsl:if>
            <xsl:if test="max:WOSERVICEADDRESS/max:SLXMUNICIPIO!=''">
                <Municipio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXMUNICIPIO"/></Municipio>
            </xsl:if>
            <TipoDireccion><xsl:value-of select="max:LOCATIONS/max:SLXURBANORURAL"/></TipoDireccion>
            <!--<Barrio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXBARRIO"/></Barrio>   SM: no lo tenemos -->
            <Barrio>1</Barrio>   <!-- pedido por Angela 29-06-2017 -->
            <Vereda>
                <xsl:if test="max:SLXVEREDA=''">0</xsl:if>
                <xsl:if test="max:SLXVEREDA!=''"><xsl:value-of select="max:SLXVEREDA"/></xsl:if>
            </Vereda>
            <xsl:if test="max:SLXTIPOTRABAJOPO!=''">
                <TipoTrabajo><xsl:value-of select="max:SLXTIPOTRABAJOPO"/></TipoTrabajo>
            </xsl:if>
            <Direccion><xsl:value-of select="max:WOSERVICEADDRESS/max:FORMATTEDADDRESS"/></Direccion>
            <CedulaSolicitante><xsl:value-of select="max:REPORTEDBY"/></CedulaSolicitante>
            <CedulaInterventor><xsl:value-of select="max:REPORTEDBY"/></CedulaInterventor>            
            <CedulaResponsable>     <!-- pedido por Angela 24-07-2017 -->
                <xsl:if test="max:LEAD!=''"><xsl:value-of select="max:LEAD"/></xsl:if>
                <xsl:if test="max:LEAD=''"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>
            </CedulaResponsable>
            <xsl:if test="max:SLXFECHAINITP!=''">
                <FechaProbableInicio><xsl:value-of select="max:SLXFECHAINITP"/></FechaProbableInicio>
            </xsl:if>
            <xsl:if test="max:SLXFECHAFINTP!=''">
                <FechaProbableFin><xsl:value-of select="max:SLXFECHAFINTP"/></FechaProbableFin>
            </xsl:if>
            <ReqLineaViva><xsl:value-of select="translate(max:SLXINCTRBLV,'10','SN')"/></ReqLineaViva>
            <CedulaLineaCuadrilla>  <!-- pedido por Angela 24-07-2017 -->
                <!--<xsl:if test="max:SLXINCTRBLV='1'"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>-->
                <xsl:value-of select="max:SLXLIDLINVIVA"/>
            </CedulaLineaCuadrilla>
            <RadCliente></RadCliente>
            <ReqManiobras><xsl:value-of select="translate(max:SLXREQMANIOBRAS,'10','SN')"/></ReqManiobras>
            <ReqCambioRed><xsl:value-of select="translate(max:SLXREQCAMBRED,'10','SN')"/></ReqCambioRed>
            <ReqSuspension><xsl:value-of select="translate(max:SLXREQSUSPCL,'10','SN')"/></ReqSuspension>
            <DesAclaracionesAvisos><xsl:value-of select="max:SLXACLAVISO"/></DesAclaracionesAvisos>
            <DesDetalleDireccion></DesDetalleDireccion>
            <UsrCreacion><xsl:value-of select="max:REPORTEDBY"/></UsrCreacion>
            <Descripcion><xsl:value-of select="max:DESCRIPTION"/></Descripcion>
            <DescripcionDetallada><xsl:value-of select="max:DESCRIPTION_LONGDESCRIPTION"/></DescripcionDetallada>
            <xsl:for-each select="max:WOACTIVITY">
                <xsl:sort select="max:TASKID"/>     <!-- Edison orden� a petici�n de Angela -->
                <Pasos>
                    <NumeroOrden><xsl:value-of select="max:TASKID"/></NumeroOrden>
                    <!--<TipPasoOrdenPrograma><xsl:apply-templates select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>-->
                    <xsl:if test="max:PLUSDPREREQTYPE!=''">
                        <TipPasoOrdenPrograma><xsl:value-of select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>
                    </xsl:if>
                    <CodigoElemento>	
                        <!-- pedido por Angela 30-06-2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                        <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                        <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o, si esta no tuviera, la ubicaci�n del activo de la OT) -->
                        <xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>
                    </CodigoElemento>
                    <!-- Nueva regla de Angela 24 Agosto '17 -->
                    <xsl:if test="max:PLUSDPREREQTYPE='1'">
                        <xsl:if test="max:PLUSDAGENCY!=''">
                            <IdeAccion><xsl:value-of select="max:PLUSDAGENCY"/></IdeAccion>
                        </xsl:if>
                    </xsl:if>
                    <NomFases>
                        <xsl:if test="max:SLXFASER = '1'">R</xsl:if>
                        <xsl:if test="max:SLXFASES = '1'">S</xsl:if>
                        <xsl:if test="max:SLXFASET = '1'">T</xsl:if>
                    </NomFases>
                    <DesDireccionElemento><xsl:value-of select="max:LOCATIONS/max:DESCRIPTION"/></DesDireccionElemento>
                    <!-- Nueva regla de Angela 24 Agosto '17 -->
                    <xsl:if test="max:PLUSDPREREQTYPE='1'">
                        <xsl:if test="max:SCHEDSTART!=''">
                            <FecEstimadaEjecucion><xsl:value-of select="max:SCHEDSTART"/></FecEstimadaEjecucion>
                        </xsl:if>
                    </xsl:if>
                    <DesPaso><xsl:value-of select="max:DESCRIPTION"/></DesPaso>     <!-- SM: "Solo para maniobras" -->
                    <NombreResponsable><xsl:value-of select="max:SLXRESPMAN"/></NombreResponsable>
                </Pasos>
            </xsl:for-each>
            <xsl:for-each select="max:DOCLINKS">
                <Adjuntos>
                    <Nombre><xsl:value-of select="max:DOCUMENT"/></Nombre>
                    <Ruta><xsl:value-of select="max:WEBURL"/></Ruta>
                </Adjuntos>
            </xsl:for-each>
        </epm:CrearTPRequest>
    </xsl:template>
</xsl:stylesheet>