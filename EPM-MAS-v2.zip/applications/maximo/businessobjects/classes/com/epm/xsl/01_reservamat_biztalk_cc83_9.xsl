<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://EPM.Materiales.BizTalk.Schemas.MaximoSolicitudMaterialesRequest" xmlns:xslt="http://xml.apache.org/xslt" exclude-result-prefixes="xslt max epm">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    
    <!--
        Transforma XML de Maximo para al invocar el servicio de Creaci�n de 
        Reserva en JDEdwards.
        
        Soporta 3 casos:
        
            A) L�neas vienen en WPMATERIAL (directreq=0)
            B) L�neas vienen en MRLINE
            C) L�neas vienen en WPITEM (linetype='ITEM' y directreq=1)
            
        El script que orquesta los llamados s�ncronos a los distintos servicios
        web de sistemas externos "inyecta" variables en campos no persistentes:
        slxauxmif_np (contiene el tipo de documento) y slxenviarjde_xsl (indica
        si la l�nea se debe considerar o no en el env�o dependiendo del tipo de
        documento o el agrupamiento que se hace en el caso de las �rdenes de 
        compra.
        
        El Control de Cambios N� 83 agreg� el caso de los materiales de cargo 
        directo. Ahora se deben crear OT's de materiales con una copia de lo que
        se enviar� por la solicitud de compra.
        
    -->
    
    <xsl:variable name="tipodoc" select="max:SCR_TIPODOC"/>
    <xsl:variable name="lines" select="(max:WPITEM|max:MRLINE)[max:LINETYPE='ITEM' and max:SLXENVIARJDE_XSL='1']"/>
    <xsl:variable name="directreq" select="$lines[1]/max:DIRECTREQ='1'"/>
    
    <epm:MaximoSolicitudMaterialesRequest>
        <SistemaOrigen>MAXIMO</SistemaOrigen>
        <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
        <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
        <TipoDocumento><xsl:value-of select="max:SLXAUXMIF_NP"/></TipoDocumento>
        <xsl:choose>
            <xsl:when test="not($lines)">   <!-- Creaci�n de OT sin l�neas en JD (solo encabezado) -->
                <CodigoAlmacen>A41</CodigoAlmacen>  <!-- para EPM est� ok enviar en duro A41 -->
                <UnidadDeNegocio><xsl:value-of select="(max:WPITEM|max:MRLINE)/max:SLXUNIDNEGOCIO"/></UnidadDeNegocio>
                <CuentaAuxiliar><xsl:value-of select="(max:WPITEM|max:MRLINE)/max:SLXCAUX"/></CuentaAuxiliar>
            </xsl:when>
            <xsl:otherwise>
                <xsl:if test="$directreq">
                    <CodigoAlmacen><xsl:value-of select="$lines[max:SLXALMACEN!='']/max:SLXALMACEN"/></CodigoAlmacen>
                    <UnidadDeNegocio>0198</UnidadDeNegocio>
                    <CuentaAuxiliar>02010101</CuentaAuxiliar>
                </xsl:if>
                <xsl:if test="not($directreq)">
                    <CodigoAlmacen><xsl:value-of select="$lines[1]/(max:LOCATION|max:STORELOC)"/></CodigoAlmacen>     <!-- Cambio pedido por Lina CC74 aprob. C. Barrera -->
                    <UnidadDeNegocio><xsl:value-of select="$lines[1]/max:SLXUNIDNEGOCIO"/></UnidadDeNegocio>
                    <CuentaAuxiliar><xsl:value-of select="$lines[1]/max:SLXCAUX"/></CuentaAuxiliar>
                </xsl:if>
            </xsl:otherwise>
        </xsl:choose>
        <Descripcion><xsl:value-of select="substring(max:DESCRIPTION, 1, 30)"/></Descripcion>
        <FechaInicio><xsl:value-of select="(.|max:WORKORDER)/max:TARGSTARTDATE"/></FechaInicio><!-- Cambio de Fechas programadas por planificados-->
        <FechaFinalizacion><xsl:value-of select="(.|max:WORKORDER)/max:TARGCOMPDATE"/></FechaFinalizacion>
        <EstadoOT>40</EstadoOT>
        <ActividadCosto><xsl:value-of select="(.|max:WORKORDER)/max:SLXACTCOST"/></ActividadCosto>
        <ObjetoCosto><xsl:value-of select="(.|max:WORKORDER)/max:SLXOBJCOSTEO"/></ObjetoCosto>
        <SolicitantePlaneador><xsl:value-of select="max:PERSON/max:PERSONID"/></SolicitantePlaneador> <!-- rut de quien aprueba la OT -->
        <Cliente>
            <xsl:choose>
                <xsl:when test="name(.)='MR'">
                    <!--<xsl:value-of select="max:REQUESTEDFOR"/>-->
                    <xsl:if test="$lines"><xsl:value-of select="$lines[max:SLXISSUETO!='']/max:SLXISSUETO"/></xsl:if>
                    <xsl:if test="not($lines)"><xsl:value-of select="max:MRLINE[max:SLXISSUETO!='']/max:SLXISSUETO"/></xsl:if>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:if test="$lines"><xsl:value-of select="$lines[max:ISSUETO!='']/max:ISSUETO"/></xsl:if>
                    <xsl:if test="not($lines)"><xsl:value-of select="max:WPITEM[max:ISSUETO!='']/max:ISSUETO"/></xsl:if>
                </xsl:otherwise>
            </xsl:choose>
        </Cliente>
        <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
        <TipoAccionEjecutar>A</TipoAccionEjecutar>
        <NumeroActivo></NumeroActivo>   <!-- debe ir nulo -->
        <NumeroMR><xsl:value-of select="max:MRNUM"/></NumeroMR>     <!-- Revisar que no haya problema al enviarla vac�a para el caso de la OT -->
        <Movilidad><xsl:value-of select="max:SLXFSM|max:WORKORDER/max:SLXFSM"/></Movilidad>
        <xsl:for-each select="$lines">
            <ListaMateriales>
                <xsl:if test="$directreq">
                    <PlantaAlmacen><xsl:value-of select="max:SLXSITEALMACEN"/></PlantaAlmacen>
                    <CodigoAlmacenReclamar><xsl:value-of select="max:SLXALMACEN"/></CodigoAlmacenReclamar>
                </xsl:if>
                <xsl:if test="not($directreq)">
                    <PlantaAlmacen><xsl:value-of select="max:STORELOCSITE"/></PlantaAlmacen>
                    <CodigoAlmacenReclamar><xsl:value-of select="max:LOCATION|max:STORELOC"/></CodigoAlmacenReclamar>
                </xsl:if>
                <CodigoMaterial><xsl:value-of select="max:ITEMNUM"/></CodigoMaterial>
                <SecuenciaItemMaterial><xsl:value-of select="max:WPITEMID|max:MRLINEID"/></SecuenciaItemMaterial>
                <CantidadSolicitada><xsl:value-of select="max:ITEMQTY|max:QTY"/></CantidadSolicitada>
                <FechaSolicitada><xsl:value-of select="max:REQUIREDATE|max:REQUIREDDATE"/></FechaSolicitada>
                <TipoCosto>
                    <xsl:if test="$directreq">4R</xsl:if>
                    <xsl:if test="not($directreq)"><xsl:value-of select="max:SLXTIPOCOSTO"/></xsl:if>
                </TipoCosto>
                <NumeroReserva><xsl:value-of select="max:REQUESTNUM"/></NumeroReserva>
                <TipoAccionMaterial>A</TipoAccionMaterial>
                <NumeroLineaMR><xsl:value-of select="max:MRLINENUM"/></NumeroLineaMR>   <!-- Revisar que no haya problema al enviarla vac�a para el caso de la OT -->
                <NumeroTarea><xsl:value-of select="max:WONUM|max:REFWO"/></NumeroTarea>
            </ListaMateriales>
        </xsl:for-each>
    </epm:MaximoSolicitudMaterialesRequest>
</xsl:template>
</xsl:stylesheet>