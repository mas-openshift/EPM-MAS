<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.NotificarEstadoOT" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:NotificarEstadoOT>
            <SistemaOrigen>MAXIMO</SistemaOrigen>
            <SistemaDestino><xsl:value-of select="max:SOURCESYSID"/></SistemaDestino>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <EstadoMaximo><xsl:value-of select="max:STATUS"/></EstadoMaximo>
            <FechaEstado><xsl:value-of select="max:STATUSDATE"/></FechaEstado>
            <OT_Maximo><xsl:value-of select="max:WONUM"/></OT_Maximo>
            <OT_Externa><xsl:value-of select="max:EXTERNALREFID"/></OT_Externa>
            <CausaNoRealizacion><xsl:value-of select="max:SLXMOTNOREAL"/></CausaNoRealizacion>
        </epm:NotificarEstadoOT>
    </xsl:template>
</xsl:stylesheet>