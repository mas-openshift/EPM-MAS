<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:ns0="http://Epm.Biztalk.GestorOT.Schemas_CA" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*">
    <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
    <max:InvokeFSMWOTAREAResponse>
        <max:FSMWOTAREASet>
            <max:WORKORDER action="Change">
                <xsl:apply-templates select="OrdenTrabajoResponse[1]"/>
                <!-- Se crean las OT hijas aqu� y se manejan por script porque al 
                parecer el framework no maneja bien la respuesta cuando son estruc-
                turas de objeto jer�rquicas. Adem�s, no se sabe hasta llegar al 
                mbo si es multitarea o no. -->
                <xsl:for-each select="OrdenTrabajoResponse">
                    <max:AUX_WORKORDER action="Change">
                        <max:WONUM><xsl:value-of select="ExternalRefID"/></max:WONUM>
                        <xsl:apply-templates select="."/>
                    </max:AUX_WORKORDER>
                </xsl:for-each>
            </max:WORKORDER>
        </max:FSMWOTAREASet>
    </max:InvokeFSMWOTAREAResponse>
</xsl:template>
<xsl:template match="OrdenTrabajoResponse">
    <max:SLXEXTSYSNUMS>
        <max:OWNERTABLE>WORKORDER</max:OWNERTABLE>
        <max:OWNERID><!-- llenado por script --></max:OWNERID>
        <max:FSMNUM><xsl:value-of select="CallID"/></max:FSMNUM>
        <max:FSMSTATUS><xsl:value-of select="Status"/></max:FSMSTATUS>
        <max:FSMDATE><xsl:value-of select="FechaEnvio"/></max:FSMDATE>
    </max:SLXEXTSYSNUMS>
</xsl:template>
</xsl:stylesheet>