<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas_Eam" xmlns:xslt="http://xml.apache.org/xslt">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:OrdenesTrabajo>
			<Operacion>CreacionOT</Operacion>
            <OrdenTrabajo>
            <epm:InformacionOrdenTrabajo>
               <General>
                  <Empresa><xsl:value-of select="max:ASSETORGID"/></Empresa>
                  <Negocio><xsl:value-of select="max:ASSETSITEID"/></Negocio>
                  <Wonum><xsl:value-of select="max:TICKETID"/></Wonum>
				  <TipoTarea></TipoTarea>
                  <Prioridad><xsl:value-of select="max:INTERNALPRIORITY"/></Prioridad>
                  <ObservacionesSolicitud>
                     <DetalleSolicitud><xsl:value-of select="max:DESCRIPTION_LONGDESCRIPTION"/></DetalleSolicitud>
                     <ObservacionSolicitud><xsl:value-of select="max:DESCRIPTION"/></ObservacionSolicitud>
                  </ObservacionesSolicitud>
                  <UnidadNegocio><xsl:value-of select="max:LOCATIONS/max:SLXCENTROACTIVIDAD"/></UnidadNegocio>
                  <RutaAprobacion><xsl:value-of select="max:SLXGRRESP"/></RutaAprobacion>
                  <Cliente><xsl:value-of select="max:AFFECTEDPERSONID"/></Cliente>
                  <Solicitante><xsl:value-of select="max:REPORTEDBYID"/></Solicitante>
               </General>
			   <Infraestructura>
                  <IdentificadorActivo><xsl:value-of select="max:ASSETNUM"/></IdentificadorActivo>
               </Infraestructura>
			   <Oterp>
                  <Oterp>    
                     <TipoAccion>A</TipoAccion>   
                  </Oterp>
               </Oterp>
            </epm:InformacionOrdenTrabajo>
            </OrdenTrabajo>
		</epm:OrdenesTrabajo>
	</xsl:template>
</xsl:stylesheet>