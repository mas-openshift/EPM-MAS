<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:act="http://Activos.Schemas.RequestAltaBajaActivosLineales" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" exclude-result-prefixes="max xsi xsl xslt" >
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <act:RequestAltaBajaActivosLineales>
            <Empresa>EPM</Empresa>
            <Fecha><xsl:value-of select="substring(*/max:FECHAENVIO,1,10)"/></Fecha>
            <!--Zero or more repetitions:-->
            <xsl:for-each select="max:SLXALTASBAJAS">
                <AltaBajaActivoLineal>
                    <Numero><xsl:value-of select="max:ASSET/max:SLXJD"/></Numero>
                    <!--Optional:-->
                    <CodigoComponente><xsl:value-of select="max:ASSET/max:CLASSSTRUCTUREID"/></CodigoComponente>
                    <CantidadModificada><xsl:value-of select="max:DELTALONGITUD"/></CantidadModificada>
                    <!--Optional:-->
                    <TipoAccion>
                        <xsl:if test="max:TIPOALTA='ALTA'">A</xsl:if>
                        <xsl:if test="max:TIPOALTA='BAJA'">B</xsl:if>
                    </TipoAccion>
                </AltaBajaActivoLineal>
            </xsl:for-each>
        </act:RequestAltaBajaActivosLineales>
    </xsl:template>
</xsl:stylesheet>