<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://Epm.Biztalk.GestorOT.Schemas.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:CrearTPRequest>
            <!--<AplicacionOrigen>EAM</AplicacionOrigen>-->
            <AplicacionOrigen>MAXIMO</AplicacionOrigen>     <!-- pedido por Angela 29-06-2017 -->
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <OTOrigen><xsl:value-of select="max:WONUM"/></OTOrigen>
            <!--<IDSolicitud></IDSolicitud>-->     <!-- Call ID no deber�a ir aqu� y lo pone el Integrador -->
            <NumeroTarea>1</NumeroTarea>
            <!--
            <xsl:for-each select="max:WOACTIVITY[max:ISTASK=0]">
                <Tareas>
                    <IDSolicitud></IDSolicitud> 
                    <NumeroTarea><xsl:value-of select="max:WOSEQUENCE"/></NumeroTarea>
                </Tareas>
            </xsl:for-each>
            -->
            <RequiereFSM><xsl:value-of select="translate(max:SLXFSM,'10','SN')"/></RequiereFSM>
            <ActivoUbicacion>	
                <!-- pedido por Angela 30-06-2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o la ubicaci�n del activo de la OT) -->
                <xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>
            </ActivoUbicacion>
            <Departamento><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXDEPART"/></Departamento>
            <Municipio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXMUNICIPIO"/></Municipio>
            <TipoDireccion><xsl:value-of select="max:LOCATIONS/max:SLXURBANORURAL"/></TipoDireccion>
            <!--<Barrio><xsl:value-of select="max:WOSERVICEADDRESS/max:SLXBARRIO"/></Barrio>   SM: no lo tenemos -->
            <Barrio>1</Barrio>   <!-- pedido por Angela 29-06-2017 -->
            <Vereda>
                <xsl:if test="max:SLXVEREDA=''">0</xsl:if>
                <xsl:if test="max:SLXVEREDA!=''"><xsl:value-of select="max:SLXVEREDA"/></xsl:if>
            </Vereda>
            <TipoTrabajo><xsl:value-of select="max:SLXTIPOTRABAJOPO"/></TipoTrabajo>
            <Direccion><xsl:value-of select="max:WOSERVICEADDRESS/max:FORMATTEDADDRESS"/></Direccion>
            <CedulaSolicitante><xsl:value-of select="max:REPORTEDBY"/></CedulaSolicitante>
            <CedulaInterventor><xsl:value-of select="max:REPORTEDBY"/></CedulaInterventor>            
            <CedulaResponsable>     <!-- pedido por Angela 24-07-2017 -->
                <xsl:if test="max:LEAD!=''"><xsl:value-of select="max:LEAD"/></xsl:if>
                <xsl:if test="max:LEAD=''"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>
            </CedulaResponsable>            
            <FechaProbableInicio>
                <xsl:call-template name="handle_nulls">
                    <xsl:with-param name="field" select="max:TARGSTARTDATE"/>
                </xsl:call-template>
            </FechaProbableInicio>
            <FechaProbableFin>
                <xsl:call-template name="handle_nulls">
                    <xsl:with-param name="field" select="max:TARGCOMPDATE"/>
                </xsl:call-template>
            </FechaProbableFin>
            <ReqLineaViva><xsl:value-of select="translate(max:SLXINCTRBLV,'10','SN')"/></ReqLineaViva>
            <CedulaLineaCuadrilla>  <!-- pedido por Angela 24-07-2017 -->
                <!--<xsl:if test="max:SLXINCTRBLV='1'"><xsl:value-of select="max:REPORTEDBY"/></xsl:if>-->
                <xsl:value-of select="max:SLXLIDLINVIVA"/>
            </CedulaLineaCuadrilla>
            <RadCliente></RadCliente>
            <ReqManiobras><xsl:value-of select="translate(max:SLXREQMANIOBRAS,'10','SN')"/></ReqManiobras>
            <ReqCambioRed><xsl:value-of select="translate(max:SLXREQCAMBRED,'10','SN')"/></ReqCambioRed>
            <ReqSuspension><xsl:value-of select="translate(max:SLXREQSUSPCL,'10','SN')"/></ReqSuspension>
            <DesAclaracionesAvisos><xsl:value-of select="max:SLXACLAVISO"/></DesAclaracionesAvisos>
            <DesDetalleDireccion></DesDetalleDireccion>
            <UsrCreacion><xsl:value-of select="max:REPORTEDBY"/></UsrCreacion>
            <xsl:for-each select="max:WOACTIVITY">
                <xsl:sort select="max:TASKID"/>     <!-- Edison orden� a petici�n de Angela -->
                <Pasos>
                    <NumeroOrden><xsl:value-of select="max:TASKID"/></NumeroOrden>
                    <!--<TipPasoOrdenPrograma><xsl:apply-templates select="max:PLUSDPREREQTYPE"/></TipPasoOrdenPrograma>-->
                    <TipPasoOrdenPrograma>
                        <xsl:call-template name="handle_nulls">
                            <xsl:with-param name="field" select="max:PLUSDPREREQTYPE"/>
                        </xsl:call-template>
                    </TipPasoOrdenPrograma>
                    <CodigoElemento>	
                        <!-- pedido por Angela 30-06-2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSETNUM"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATION"/></xsl:if>-->
                        <!-- pedido por Angela a trav�s de Javier Garc�a 02/08/2017 
                        <xsl:if test="max:ASSETNUM!=''"><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></xsl:if>
                        <xsl:if test="max:ASSETNUM=''"><xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/></xsl:if>-->
                        <!-- pedido por Angela 22 de Agosto '17 (se relaciona la ubicaci�n de la OT o la ubicaci�n del activo de la OT) -->
                        <xsl:value-of select="max:LOCATIONS/max:SLXALIAS"/>
                    </CodigoElemento>
                    <IdeAccion>
                        <xsl:call-template name="handle_nulls">
                            <xsl:with-param name="field" select="max:PLUSDAGENCY"/>
                        </xsl:call-template>                        
                    </IdeAccion>
                    <NomFases>
                        <xsl:if test="max:SLXFASER = '1'">R</xsl:if>
                        <xsl:if test="max:SLXFASES = '1'">S</xsl:if>
                        <xsl:if test="max:SLXFASET = '1'">T</xsl:if>
                    </NomFases>
                    <DesDireccionElemento><xsl:value-of select="max:LOCATIONS/max:DESCRIPTION"/></DesDireccionElemento>
                    <FecEstimadaEjecucion>
                        <xsl:call-template name="handle_nulls">
                            <xsl:with-param name="field" select="max:SCHEDSTART"/>
                        </xsl:call-template>
                    </FecEstimadaEjecucion>    <!-- SM: "Solo para maniobras" -->
                    <DesPaso><xsl:value-of select="max:DESCRIPTION"/></DesPaso>     <!-- SM: "Solo para maniobras" -->
                    <NombreResponsable><xsl:value-of select="max:SLXRESPMAN"/></NombreResponsable>
                </Pasos>
            </xsl:for-each>
            <xsl:for-each select="max:DOCLINKS">
                <Adjuntos>
                    <Nombre><xsl:value-of select="max:DOCUMENT"/></Nombre>
                    <Ruta><xsl:value-of select="max:WEBURL"/></Ruta>
                </Adjuntos>
            </xsl:for-each>
        </epm:CrearTPRequest>
    </xsl:template>
    <!-- Template/funci�n para manejar nulos -->
    <xsl:template name="handle_nulls">
        <xsl:param name="field"/>
        <xsl:value-of select="$field"/>
        <xsl:if test="$field=''">
            <xsl:attribute name="xsi:nil">true</xsl:attribute>
        </xsl:if>
    </xsl:template>
</xsl:stylesheet>