<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:xslt="http://xml.apache.org/xslt" xmlns:act="http://Activos.Schemas.TrasladoOperacionRequest" exclude-result-prefixes="xslt xsl max">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>

<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  
    <act:TrasladoOperacionRequest>
        <Empresa><xsl:value-of select="max:SLXTOPERAR/max:ORGID"/></Empresa>
        <Preactivo><xsl:value-of select="max:SLXTOPERAR/max:SLXPREACTIVO"/></Preactivo>
        <FechaTraslado><xsl:value-of select="substring(max:SLXTOPERAR/max:FECHATOF,1,10)"/></FechaTraslado>
        <Simulacion><xsl:value-of select="max:SLXTOPERAR/max:SLXSIMULAR"/></Simulacion>
        <Activos>
            <xsl:for-each select="max:SLXTOPERAR/max:SLXTOPERARLAGP">
                <Activo>
                    <NumeroActivo><xsl:value-of select="max:SLXJD"/></NumeroActivo>
                    <MontoDistribuir><!-- ? --></MontoDistribuir>
                    <PorcentajeDistribuir><xsl:value-of select="max:PCTJEDISTRIB"/></PorcentajeDistribuir>
                    <ObjetoCosto><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoCosto>
                    <VidaUtilMeses><!-- nulo seg n documento --></VidaUtilMeses>
                    <JustificacionCambioVidaUtil></JustificacionCambioVidaUtil>
                </Activo>
            </xsl:for-each>
        </Activos>
    </act:TrasladoOperacionRequest>
</xsl:template>
</xsl:stylesheet>