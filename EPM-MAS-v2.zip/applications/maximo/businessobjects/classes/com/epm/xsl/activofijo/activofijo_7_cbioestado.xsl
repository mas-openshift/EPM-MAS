<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:act="http://Activos.Schemas.RequestCambiarEstado" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" exclude-result-prefixes="max xsi xsl xslt" >
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <act:RequestCambiarEstado>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <Fecha><xsl:value-of select="substring(max:STATUSDATE,1,10)"/></Fecha>
            <PreActivos>
                <act:PreActivo>
                    <Numero><xsl:value-of select="max:SLXJD"/></Numero>
                    <!--<CentroActividad><xsl:value-of select="max:PERSON/max:SLXCENACT"/></CentroActividad>-->     <!-- no s� por qu� estaba as�, el documento dice LOCATIONS.SLXCENTROACTIVIDAD -->
                    <CentroActividad><xsl:value-of select="max:LOCATIONS/max:SLXCENTROACTIVIDAD"/></CentroActividad>
                    <!-- El documento dice que s� pero Lina dice que no hay que mandarlos (pruebas t�cnicas, Lina).
                    <UnidadDeNegocio><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='0']"/></UnidadDeNegocio>
                    <CuentaObjeto><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='1']"/></CuentaObjeto>
                    <CuentaAuxiliar><xsl:value-of select="max:GLACCOUNT/max:GLCOMP[@glorder='2']"/></CuentaAuxiliar>-->
                    <Estado><xsl:value-of select="max:STATUS"/></Estado>
                    <ObjetoCostoDestino><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoCostoDestino>
                </act:PreActivo>
            </PreActivos>
        </act:RequestCambiarEstado>            
    </xsl:template>
</xsl:stylesheet>