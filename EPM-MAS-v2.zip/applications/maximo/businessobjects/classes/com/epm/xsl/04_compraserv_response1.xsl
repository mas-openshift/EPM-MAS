<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xslt="http://xml.apache.org/xslt" xmlns:ns0="http://ProcurementManager.Schemas.ProcessPurchaseOrderResponse">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/ns0:ProcessPurchaseOrderResponse/Header">
    <xsl:text>&#xa;</xsl:text>   <!-- Enter -->
    <max:InvokeERPCOMPRASERVResponse xmlns:max="http://www.ibm.com/maximo">
        <max:ERPCOMPRASERVSet>
            <max:WORKORDER action="Change">
                <max:SLXAUXMIF_NP><xsl:value-of select="ns0:ProcessPurchaseOrderResponse/Header/DocumentNumber"/></max:SLXAUXMIF_NP>
                <max:DESCRIPTION_LONGDESCRIPTION><xsl:value-of select="ns0:ProcessPurchaseOrderResponse/ErrorMessage"/></max:DESCRIPTION_LONGDESCRIPTION>
                <xsl:for-each select="Detail">
                    <max:WPITEM>
                        <max:SLXEXTSYSNUMS>
                            <max:OWNERTABLE>WPITEM</max:OWNERTABLE>
                            <max:DOCUMENTLINENUMBER><xsl:value-of select="PurchaseOrderLineNumber"/></max:DOCUMENTLINENUMBER>
                            <max:PURCHASEORDERLINENUMBER><xsl:value-of select="PurchaseOrderLineNumber"/></max:PURCHASEORDERLINENUMBER>
                            <max:DOCUMENTNUMBER><xsl:value-of select="../DocumentNumber"/></max:DOCUMENTNUMBER>
                            <max:DOCUMENTCOMPANY><xsl:value-of select="../DocumentCompany"/></max:DOCUMENTCOMPANY>
                            <max:DOCUMENTTYPECODE><xsl:value-of select="../DocumentCompany"/></max:DOCUMENTTYPECODE>
                        </max:SLXEXTSYSNUMS>
                    </max:WPITEM>
                </xsl:for-each>
            </max:WORKORDER>
        </max:ERPCOMPRASERVSet>
    </max:InvokeERPCOMPRASERVResponse>
</xsl:template>
</xsl:stylesheet>