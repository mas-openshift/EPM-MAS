<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:act="http://Activos.Schemas.RequestCrearActivosPuntuales" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" exclude-result-prefixes="max xsi xsl xslt" >
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <act:RequestCrearActivosPuntuales>
            <Empresa><xsl:value-of select="max:ORGID"/></Empresa>
            <TipoAccionEjecutar>2</TipoAccionEjecutar>
            <Activos>
                <!--Zero or more repetitions:-->
                <act:Activo>
                    <Codigo><xsl:value-of select="max:SLXJD"/></Codigo>
                    <Departamento><xsl:value-of select="max:LOCATIONS/max:SLXDEPART"/></Departamento>
                    <Municipio><xsl:value-of select="max:LOCATIONS/max:SLXMUNICIPIO"/></Municipio>
                    <UnidadDeNegocio></UnidadDeNegocio>
                    <CuentaObjeto></CuentaObjeto>
                    <CuentaAuxiliar></CuentaAuxiliar>
                    <MontoImpuestos></MontoImpuestos>
                    <IdEstructuraClase></IdEstructuraClase>
                    <ObjetoDeCosto><xsl:value-of select="max:SLXOBJCOSTEO"/></ObjetoDeCosto>
                    <Pais></Pais>
                    <ActivoPadre></ActivoPadre>
                    <CentroActividad><xsl:value-of select="max:LOCATIONS/max:SLXCENTROACTIVIDAD"/></CentroActividad>
                    <FechaAdquisicion></FechaAdquisicion>
                    <Descripcion></Descripcion>
                    <Descripcion1></Descripcion1>
                    <Descripcion2></Descripcion2>
                    <NumeroSerie></NumeroSerie>
                    <Estado><xsl:value-of select="max:STATUS"/></Estado>
                    <NumeroUnidad></NumeroUnidad>
                    <Numero></Numero>
                    <Planta><xsl:value-of select="max:SITEID"/></Planta>
                    <VidaUtilMeses></VidaUtilMeses>
                    <JustificacionCambioVidaUtil><xsl:value-of select="max:SLXJUSTIFVIDAUTIL"/></JustificacionCambioVidaUtil>
                </act:Activo>
            </Activos>
        </act:RequestCrearActivosPuntuales>
    </xsl:template>
</xsl:stylesheet>