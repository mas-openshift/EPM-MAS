<?xml version="1.0" encoding="ISO-8859-1"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:max="http://www.ibm.com/maximo" xmlns:epm="http://EPM.BizTalk.TrabajosProgramados.Schemas.CrearTP.CrearTPRequest" xmlns:xslt="http://xml.apache.org/xslt" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
    <xsl:template match="text()|@*">
    </xsl:template>
    <xsl:template match="/*/*/*">
        <xsl:text>&#xa;</xsl:text>  <!-- Enter -->
        <epm:CrearTPRequest>
            <AplicacionOrigen>MAXIMO</AplicacionOrigen>
            <Pais><xsl:value-of select="max:PAIS"/></Pais>
            <Empresa>8909049961</Empresa>    <!-- "Valor fijo.. NIT de EPM" -->
            <Negocio><xsl:value-of select="max:SITEID"/></Negocio>
            <OTOrigen><xsl:value-of select="max:RELATEDRECORD/max:WORKORDER/max:WONUM"/></OTOrigen>
            <IDSolicitud><xsl:value-of select="max:NUMPOPADRE"/></IDSolicitud>
            <NumeroTarea></NumeroTarea>
            <TipoTarea></TipoTarea>
            <!--Zero or more repetitions:-->
            <!--<Tareas>
                <IDSolicitud></IDSolicitud>
                <NumeroTarea></NumeroTarea>
            </Tareas>-->
            <RequiereFSM></RequiereFSM>
            <ActivoUbicacion></ActivoUbicacion>
            <Departamento><xsl:value-of select="max:DEPARTAMENTO"/></Departamento>
            <Municipio><xsl:value-of select="max:MUNICIPIO"/></Municipio>
            <TipoDireccion><xsl:value-of select="max:SLXURBANORURAL"/></TipoDireccion>
            <Barrio></Barrio>
            <Vereda></Vereda>
            <TipoTrabajo></TipoTrabajo>
            <Direccion><xsl:value-of select="max:DIRECCION"/></Direccion>
            <CedulaSolicitante></CedulaSolicitante>
            <Observacion></Observacion>
            <CedulaInterventor></CedulaInterventor>
            <CedulaResponsable></CedulaResponsable>
            <FechaProbableInicio><xsl:value-of select="max:FECHAPROGINICIAL"/></FechaProbableInicio>
            <FechaProbableFin><xsl:value-of select="max:FECHAPROGFIN"/></FechaProbableFin>
            <ReqLineaViva></ReqLineaViva>
            <CedulaLineaCuadrilla></CedulaLineaCuadrilla>
            <RadCliente></RadCliente>
            <ReqManiobras></ReqManiobras>
            <ReqCambioRed></ReqCambioRed>
            <ReqSuspension></ReqSuspension>
            <DesAclaracionesAvisos></DesAclaracionesAvisos>
            <DesDetalleDireccion></DesDetalleDireccion>
            <UsrCreacion></UsrCreacion>
            <Descripcion><xsl:value-of select="max:DESCRIPTION"/></Descripcion>
            <DescripcionDetallada><xsl:value-of select="max:DESCRIPTION_LONGDESCRIPTION"/></DescripcionDetallada>
            <!--Zero or more repetitions:-->
            <xsl:for-each select="max:WOACTIVITY">
                <Pasos>
                    <NumeroOrden><xsl:value-of select="max:WONUM"/></NumeroOrden>
                    <TipPasoOrdenPrograma></TipPasoOrdenPrograma>
                    <CodigoElemento><xsl:value-of select="max:ASSET/max:SLXNUMOPE"/></CodigoElemento>
                    <IdeAccion><xsl:value-of select="max:PLUSDAGENCY"/></IdeAccion>
                    <NomFases></NomFases>
                    <DesDireccionElemento><xsl:value-of select="max:ASSET/max:SLXUBINTERNA"/></DesDireccionElemento>
                    <FecEstimadaEjecucion></FecEstimadaEjecucion>
                    <DesPaso><xsl:value-of select="max:DESCRIPTION"/></DesPaso>
                    <NombreResponsable></NombreResponsable>
                    <TipoElemento><xsl:value-of select="max:ASSET/max:PLUSSFEATURECLASS"/></TipoElemento>
                    <IdentificadorInterrupcion><xsl:value-of select="max:SLXMAXNUMINT"/></IdentificadorInterrupcion>
                    <FechaHoraFinProgramada><xsl:value-of select="max:SCHEDFINISH"/></FechaHoraFinProgramada>
                    <FechaHoraInicioProgramada><xsl:value-of select="max:SCHEDSTART"/></FechaHoraInicioProgramada>
                </Pasos>
            </xsl:for-each>
            <!--Zero or more repetitions:-->
            <!--<Adjuntos>
                <Nombre></Nombre>
                <Ruta></Ruta>
            </Adjuntos>-->
            <CoordenadaX></CoordenadaX>
            <CoordenadaY></CoordenadaY>
            <NombreContacto></NombreContacto>
            <TelefonoContacto></TelefonoContacto>
        </epm:CrearTPRequest>
    </xsl:template>
</xsl:stylesheet>