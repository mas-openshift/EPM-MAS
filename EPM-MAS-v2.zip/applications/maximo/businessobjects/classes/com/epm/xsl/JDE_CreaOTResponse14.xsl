<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:max="http://www.ibm.com/maximo" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xslt="http://xml.apache.org/xslt">
<xsl:output method="xml" version="1.0" encoding="UTF-8" indent="yes" xslt:indent-amount="2"/>
<xsl:template match="text()|@*">
</xsl:template>
<xsl:template match="/*/*">
    <xsl:text>&#xa;</xsl:text>  <!-- new line -->
	<max:InvokeJDECREAOTResponse>
		<max:JDECREAOTSet>
			<max:SR action="Change">
				<max:SLXOTJDE><xsl:value-of select="CallID"/></max:SLXOTJDE>
				<max:SLXTIENEOTJDE>1</max:SLXTIENEOTJDE>
			</max:SR>
		</max:JDECREAOTSet>
	</max:InvokeJDECREAOTResponse>
</xsl:template>
</xsl:stylesheet>
