IBM Corporation

IBM(R) Maximo(R) Limited Availability Test Fix for Release 9.1.7

Note: Before using this information and the product it supports, read the information in
the Notices section at the end of this document.

(C) Copyright International Business Machines Corporation 2021. All rights reserved.
US Government Users Restricted Rights - Use, duplication or disclosure restricted by
GSA ADP Schedule Contract with IBM Corp.

===============================================================================================
Table of Contents
===============================================================================================


	I.   Introduction
	II.  Installation Instructions
	III. Manual Changes
	IV.  Issues Resolved
	V.   Notices


===============================================================================================
I. Introduction
===============================================================================================


LA Test Fix is a fix requested by a customer.

Customers should validate this LA Test Fix by installing it in a test environment before
rolling it out to a production environment.

LA Test Fixes, by their very nature, do not go through a quality assurance cycle and may
not be included in the latest available program patch.

IBM is providing notice that a LA Test Fix is not a standard deliverable from IBM Support
& Development. Unlike formal Fix Packs, and to a certain degree, Interim Fixes based
on recent fixpacks, LA Test Fixes do not undergo a full testing and validation effort. Although
the LA Test Fix is designed to correct a specific reported defect or issue, the nature of this
type of update can introduce unrelated problems. It is the responsibility of the customer to
perform a thorough testing effort in their environment.

Fixes delivered in this capacity can also cause supportability issues in the future for the
customer as well as IBM Support and Development. These issues include, but are not limited to,
latency on turn around time for future fix deliverables as well as root cause analysis of
potential future reported problems.

IBM Support recommends that the customer obtain fixes through the standard Fix Pack delivery
method. If a customer's business needs cannot accommodate a Fix Pack, then the next favorable
correction should be applied and contained in an Interim Fix. If an Interim Fix cannot be applied
and a LA Test Fix is requested, the customer must acknowledge the potential immediate and future
risk in implementing the LA Test Fix.


===============================================================================================
II. Installation Instructions
===============================================================================================


The LA Test Fix file should be extracted into the Maximo root directory.

Before extracting the files into the Maximo root directory, back up the existing Maximo files
and make a backup copy of the database.

When extracting, make sure that you select the Overwrite existing files and the
Use folder names options.


NOTE	Uninstall Information - This LA Test Fix is provided to you as a zip file.
	It overwrites your existing Maximo directory structure and may contain database scripts
	that modify your database.
	If you want to reverse your changes, you must restore your backed-up versions of the
	Maximo directory and database.


Follow these steps to apply this LA Test Fix:

	1 Ensure that no database configuration changes are pending.

	2 Shut down the Maximo application server.

	3 Back up the database.

	4 Copy the Maximo directory.

	5 Unzip the LA Test Fix zip file supplied for this fix.

	6 Apply any manual updates listed in the Manual Changes section.

	7 Run UpdateDB
		a. At a DOS prompt, change directory to '<maximo root>\tools\maximo'.
		   For example, c:\IBM\SMP\maximo\tools\maximo.

		b. Run 'updatedb.bat'.

	8 Delete the application server cache folders.

		For Oracle WebLogic Server, delete the 'cache' and 'tmp' folders in
		<BEA_Root>\user_projects\domains\mydomain\servers\AdminServer\.
		Example:
		  C:\bea923\user_projects\domains\max711domain\servers\AdminServer\cache
		  C:\bea923\user_projects\domains\max711domain\servers\AdminServer\tmp

		For IBM WebSphere(R) Application Server, delete the cache folder in
		<WebSphere_Root>\AppServer\profiles\Custom01\temp\<machinename>Node01\MAXIMOSERVER

	9 Delete the Web browser cache on every computer that uses Maximo base services.

	10 Rebuild and redeploy the EAR files, and then restart the application server.


===============================================================================================
III. Manual Changes
===============================================================================================


APAR: DT459958

Manual Changes: na


===============================================================================================
IV. Issues Resolved
===============================================================================================


APAR: DT459958

Defect: MASISMIG-79127

Description: Cognos reports with folder or file names containing Japanese characters cannot be opened from Manage

Database Scripts: n/a


===============================================================================================
V. Notices
===============================================================================================


This information was developed for products and services offered in the U.S.A.
IBM may not offer the products, services, or features discussed in this document
in other countries. Consult your local IBM representative for information on the
products and services currently available in your area. Any reference to an IBM
product, program, or service is not intended to state or imply that only that IBM
product, program, or service may be used. Any functionally equivalent product,
program, or service that does not infringe any IBM intellectual property right
may be used instead. However, it is the user's responsibility to evaluate and verify
the operation of any non-IBM product, program, or service.
IBM may have patents or pending patent applications covering subject matter
described in this document. The furnishing of this document does not grant you
any license to these patents. You can send license inquiries, in writing, to:
	IBM Director of Licensing
	IBM Corporation
	North Castle Drive
	Armonk, NY 10504-1785
	U.S.A.

For license inquiries regarding double-byte (DBCS) information, contact the IBM
Intellectual Property Department in your country or send inquiries, in writing, to:
	Intellectual Property Licensing
	Legal and Intellectual Property Law
	IBM Japan, Ltd.
	1623-14, Shimotsuruma, Yamato-shi
	Kanagawa 242-8502 Japan

The following paragraph does not apply to the United Kingdom or any other
country where such provisions are inconsistent with local law:

INTERNATIONAL BUSINESS MACHINES CORPORATION PROVIDES THIS
PUBLICATION "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER
EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS
FOR A PARTICULAR PURPOSE. Some states do not allow disclaimer of express
or implied warranties in certain transactions, therefore, this statement may not
apply to you.

This information could include technical inaccuracies or typographical errors.
Changes are periodically made to the information herein; these changes will be
incorporated in new editions of the publication. IBM may make improvements
and/or changes in the product(s) and/or the program(s) described in this
publication at any time without notice.

Any references in this information to non-IBM Web sites are provided for
convenience only and do not in any manner serve as an endorsement of those
Web sites. The materials at those Web sites are not part of the materials for this
IBM product and use of those Web sites is at your own risk.

IBM may use or distribute any of the information you supply in any way it
believes appropriate without incurring any obligation to you.
Licensees of this program who wish to have information about it for the purpose
of enabling: (i) the exchange of information between independently created
programs and other programs (including this one) and (ii) the mutual use of the
information which has been exchanged, should contact:
	IBM Corporation
	2Z4A/101
	11400 Burnet Road
	Austin, TX 78758 U.S.A.

Such information may be available, subject to appropriate terms and conditions,
including in some cases, payment of a fee.

The licensed program described in this document and all licensed material
available for it are provided by IBM under terms of the IBM Customer
Agreement, IBM International Program License Agreement or any equivalent
agreement between us.

Information concerning non-IBM products was obtained from the suppliers of
those products, their published announcements or other publicly available
sources. IBM has not tested those products and cannot confirm the accuracy of
performance, compatibility or any other claims related to non-IBM products.
Questions on the capabilities of non-IBM products should be addressed to the
suppliers of those products.

All statements regarding IBM's future direction or intent are subject to change or
withdrawal without notice, and represent goals and objectives only.
This information contains examples of data and reports used in daily business
operations. To illustrate them as completely as possible, the examples include the
names of individuals, companies, brands, and products. All of these names are
fictitious and any similarity to the names and addresses used by an actual
business enterprise is entirely coincidental.
If you are viewing this information softcopy, the photographs and color
illustrations may not appear.



Trademarks

IBM, the IBM logo, and ibm.com are trademarks or registered trademarks of International
Business Machines Corp., registered in many jurisdictions worldwide. Other product and
service names might be trademarks of IBM or other companies. A current list of IBM trademarks
is available on the Web at Copyright and trademark information at www.ibm.com/legal/copytrade.shtml.


Adobe, the Adobe logo, PostScript, and the PostScript logo are either registered
trademarks or trademarks of Adobe Systems Incorporated in the United States,
and/or other countries.

Java and all Java-based trademarks and logos are trademarks Oracle and/or its affiliates.

Linux is a registered trademark of Linus Torvalds in the United States, other
countries, or both.

Intel, Intel logo, Intel Inside, Intel Inside logo, Intel Centrino, Intel Centrino logo,
Celeron, Intel Xeon, Intel SpeedStep, Itanium, and Pentium are trademarks or
registered trademarks of Intel Corporation or its subsidiaries in the United States
and other countries.

Microsoft, Windows, Windows NT, and the Windows logo are trademarks of
Microsoft Corporation in the United States, other countries, or both.

UNIX is a registered trademark of The Open Group in the United States and other
countries.
